/**
 * ダッシュボード用タブバーコンポーネント
 */

'use client';

interface TabBarProps {
  activeTab: 'theme-analysis' | 'tab2' | 'tab3' | 'tab4';
  onTabChange: (tab: 'theme-analysis' | 'tab2' | 'tab3' | 'tab4') => void;
}

export function DashboardTabBar({ activeTab, onTabChange }: TabBarProps) {
  const tabs = [
    { id: 'tab2' as const, label: '時系列分析' },
    { id: 'theme-analysis' as const, label: 'テーマ別施策分析' },
    { id: 'tab3' as const, label: '機能3（準備中）' },
    { id: 'tab4' as const, label: '機能4（準備中）' },
  ];

  return (
    <div style={{ 
      display: 'flex', 
      gap: '8px', 
      marginBottom: '24px', 
      borderBottom: '1px solid #E0E0E0' 
    }}>
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          style={{
            padding: '12px 24px',
            border: 'none',
            background: 'transparent',
            color: activeTab === tab.id ? '#4262FF' : '#808080',
            borderBottom: activeTab === tab.id ? '2px solid #4262FF' : '2px solid transparent',
            cursor: 'pointer',
            fontWeight: activeTab === tab.id ? 600 : 400,
            fontSize: '14px',
            fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            transition: 'all 150ms',
          }}
          onMouseEnter={(e) => {
            if (activeTab !== tab.id) {
              e.currentTarget.style.color = '#1A1A1A';
            }
          }}
          onMouseLeave={(e) => {
            if (activeTab !== tab.id) {
              e.currentTarget.style.color = '#808080';
            }
          }}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}

