/**
 * Graphviz タブ3: ラック内サーバー・ポート
 * ラック内のサーバーや機器の詳細、ポート構成、接続詳細を管理
 */

'use client';

export { Tab3 } from './Tab3/index';

