/**
 * Graphviz 機能1タブコンポーネント
 * 分割されたコンポーネントを統合
 */

export { Tab1 } from './Tab1/index';
