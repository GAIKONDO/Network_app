/**
 * Graphviz タブ2: 棟内機器構成
 * 棟内のラック配置、機器構成、機器間の接続を管理
 */

'use client';

export { Tab2 } from './Tab2/index';

