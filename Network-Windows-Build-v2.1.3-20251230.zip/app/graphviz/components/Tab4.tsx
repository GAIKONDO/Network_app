/**
 * Graphviz タブ4: 機器詳細・シーケンス
 * 個別サーバーの詳細設定、アプリケーション構成、シーケンス図を管理
 */

'use client';

export { Tab4 } from './Tab4/index';

