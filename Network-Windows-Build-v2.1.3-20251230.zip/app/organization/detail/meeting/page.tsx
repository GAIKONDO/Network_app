'use client';

import { useState, useEffect, useCallback, useRef, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Layout from '@/components/Layout';
import { getMeetingNoteById, saveMeetingNote, getOrgTreeFromDb, generateUniqueId, getTopicsByMeetingNote } from '@/lib/orgApi';
// import { saveCompanyMeetingNote } from '@/lib/companiesApi';
import type { MeetingNote, OrgNodeData } from '@/lib/orgApi';
// import type { CompanyMeetingNote } from '@/lib/companiesApi';
import type { Topic, TopicSemanticCategory, TopicImportance } from '@/types/topicMetadata';
import { saveTopicEmbeddingAsync } from '@/lib/topicEmbeddings';
import { generateTopicMetadata, extractEntities, extractRelations } from '@/lib/topicMetadataGeneration';
import { getAvailableOllamaModels } from '@/lib/pageGeneration';
import type { Entity, EntityType } from '@/types/entity';
import type { Relation, RelationType } from '@/types/relation';
import { getRelationsByTopicId, createRelation, deleteRelation } from '@/lib/relationApi';
import { createEntity, getEntitiesByOrganizationId, getEntitiesByCompanyId, deleteEntity } from '@/lib/entityApi';
import { callTauriCommand } from '@/lib/localFirebase';
import { deleteTopicFromChroma } from '@/lib/chromaSync';
import { EditIcon, AIIcon, DeleteIcon } from './components/Icons';
import { devLog, devWarn, markdownComponents } from './utils';
import type { TabType, MonthTab, SummaryTab, MonthContent, MeetingNoteData } from './types';
import { MONTHS, SUMMARY_TABS, GPT_MODELS, RELATION_TYPE_LABELS, ENTITY_TYPE_LABELS } from './constants';
import DeleteItemConfirmModal from './components/modals/DeleteItemConfirmModal';
import DeleteTopicConfirmModal from './components/modals/DeleteTopicConfirmModal';
import TableOfContentsModal from './components/modals/TableOfContentsModal';
import DeleteEntitiesConfirmModal from './components/modals/DeleteEntitiesConfirmModal';
import DeleteRelationsConfirmModal from './components/modals/DeleteRelationsConfirmModal';
import SimilarTopicsModal from './components/modals/SimilarTopicsModal';
import AddEntityModal from './components/modals/AddEntityModal';
import AddRelationModal from './components/modals/AddRelationModal';
import AIGenerationModal from './components/modals/AIGenerationModal';
import TopicModal from './components/modals/TopicModal';
import HeaderSection from './components/HeaderSection';
import TabNavigation from './components/TabNavigation';
import SidebarSection from './components/SidebarSection';
import SummaryContentSection from './components/SummaryContentSection';
import MonthSummarySection from './components/MonthSummarySection';
import MeetingItemCard from './components/MeetingItemCard';
import { useMeetingNoteData } from './hooks/useMeetingNoteData';
import { useEditMode } from './hooks/useEditMode';
import { useTopicManagement } from './hooks/useTopicManagement';
import { useAIGeneration } from './hooks/useAIGeneration';
import { useEntityRelationManagement } from './hooks/useEntityRelationManagement';

function MeetingNoteDetailPageContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  // organizationIdは'id'または'organizationId'パラメータから取得（後方互換性のため）
  const organizationId = (searchParams?.get('organizationId') || searchParams?.get('id')) as string;
  const meetingId = searchParams?.get('meetingId') as string;
  const topicIdFromUrl = searchParams?.get('topicId') as string | null;
  
  const [activeTab, setActiveTab] = useState<TabType>('april');
  const [activeSection, setActiveSection] = useState<string>('summary');
  const [downloadingJson, setDownloadingJson] = useState(false);
  
  // タブの順番管理（useMeetingNoteDataの前に定義する必要がある）
  const [tabOrder, setTabOrder] = useState<TabType[]>(() => {
    // 初期順番: 月タブ → 総括タブ
    return [
      ...MONTHS.map(m => m.id),
      ...SUMMARY_TABS.map(t => t.id),
    ];
  });
  
  // カスタムフックでデータ管理
  const {
    meetingNote,
    orgData,
    allOrganizations,
    loading,
    error,
    monthContents,
    setMonthContents,
    customTabLabels,
    setCustomTabLabels,
    hasUnsavedChanges,
    setHasUnsavedChanges,
    savingStatus,
    setSavingStatus,
    downloadingHtml,
    handleManualSave,
    handleDownloadJson: handleDownloadJsonFromHook,
    handleDownloadHtml: handleDownloadHtmlFromHook,
  } = useMeetingNoteData({
    organizationId,
    meetingId,
    activeTab,
    onSetActiveSection: setActiveSection,
    tabOrder,
  });

  // 組織変更ハンドラー
  const handleOrganizationChange = async (newOrganizationId: string) => {
    if (!meetingNote || !meetingId) {
      console.error('❌ [ページ] 議事録データがありません');
      return;
    }

    try {
      console.log('🔄 [ページ] 組織変更を開始:', {
        meetingId,
        currentOrganizationId: organizationId,
        newOrganizationId,
      });

      // 1. 議事録のorganizationIdを更新
      await saveMeetingNote({
        ...meetingNote,
        organizationId: newOrganizationId,
      });

      console.log('✅ [ページ] 議事録の組織変更が完了しました');

      // 2. 関連するすべてのトピックのorganizationIdを更新
      const topics = await getTopicsByMeetingNote(meetingId);
      console.log(`📖 [ページ] 関連トピック数: ${topics.length}件`);

      if (topics.length > 0) {
        // TauriコマンドでSQLiteを直接更新
        for (const topic of topics) {
          try {
            await callTauriCommand('sql_exec', {
              sql: `UPDATE topics 
                    SET organizationId = ?1, 
                        chromaSynced = 0,
                        updatedAt = datetime('now')
                    WHERE id = ?2`,
              params: [newOrganizationId, topic.id],
            });
            console.log(`✅ [ページ] トピック ${topic.id} の組織変更が完了しました`);
          } catch (topicError: any) {
            console.error(`❌ [ページ] トピック ${topic.id} の更新エラー:`, topicError);
            // エラーが発生しても続行
          }
        }
        console.log(`✅ [ページ] 全トピックの組織変更が完了しました（${topics.length}件）`);
      }

      console.log('✅ [ページ] 組織変更が完了しました。ページを遷移します。');

      // 新しい組織の議事録ページに遷移
      router.push(`/organization/detail/meeting?organizationId=${newOrganizationId}&meetingId=${meetingId}`);
    } catch (error: any) {
      console.error('❌ [ページ] 組織変更エラー:', error);
      throw error;
    }
  };
  
  // タブ名編集モード
  const [editingTabLabel, setEditingTabLabel] = useState<TabType | null>(null);
  const [editingTabLabelValue, setEditingTabLabelValue] = useState<string>('');
  
  // 目次モーダル
  const [showTableOfContentsModal, setShowTableOfContentsModal] = useState(false);
  const [expandedMonthInTOC, setExpandedMonthInTOC] = useState<TabType | null>(null);
  
  // タブの順番を初期化（データ読み込み時に設定）
  useEffect(() => {
    if (meetingNote?.content) {
      try {
        const parsed = JSON.parse(meetingNote.content) as MeetingNoteData & { 
          customTabLabels?: Record<TabType, string | undefined>;
          tabOrder?: TabType[];
        };
        if (parsed.tabOrder && Array.isArray(parsed.tabOrder)) {
          // 保存された順番がある場合はそれを使用
          const allTabs = new Set([...MONTHS.map(m => m.id), ...SUMMARY_TABS.map(t => t.id)]);
          const validOrder = parsed.tabOrder.filter(tab => allTabs.has(tab));
          // 存在しないタブを追加
          const missingTabs = [...allTabs].filter(tab => !validOrder.includes(tab));
          setTabOrder([...validOrder, ...missingTabs]);
        }
      } catch (e) {
        // パースエラーは無視
      }
    }
  }, [meetingNote?.content]);
  
  // 編集モード管理（カスタムフック）
  const {
    editingMonth,
    editingSection,
    editingContent,
    editingItemTitle,
    editingItemDate,
    editingItemTime,
    setEditingMonth,
    setEditingSection,
    setEditingContent,
    setEditingItemTitle,
    setEditingItemDate,
    setEditingItemTime,
    handleStartEditSummary,
    handleStartEditItem,
    handleStartEditItemTitle,
    handleCancelEdit,
    handleSaveEdit,
  } = useEditMode({
    monthContents,
    setMonthContents,
    meetingNote,
    setHasUnsavedChanges,
    setSavingStatus,
  });
  
  // 削除確認モーダル
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [deleteTargetTab, setDeleteTargetTab] = useState<TabType | null>(null);
  const [deleteTargetItemId, setDeleteTargetItemId] = useState<string | null>(null);
  
  // トピック管理（カスタムフック）
  const {
    showDeleteTopicModal,
    deleteTargetTopicItemId,
    deleteTargetTopicId,
    handleDeleteTopic,
    confirmDeleteTopic,
    cancelDeleteTopic,
    showTopicModal,
    setShowTopicModal,
    editingTopicItemId,
    setEditingTopicItemId,
    editingTopicId,
    setEditingTopicId,
    topicTitle,
    setTopicTitle,
    topicContent,
    setTopicContent,
    topicSemanticCategory,
    setTopicSemanticCategory,
    topicKeywords,
    setTopicKeywords,
    topicSummary,
    setTopicSummary,
    topicImportance,
    setTopicImportance,
    isGeneratingMetadata,
    setIsGeneratingMetadata,
    pendingMetadata,
    setPendingMetadata,
    topicMetadataModelType,
    setTopicMetadataModelType,
    topicMetadataSelectedModel,
    setTopicMetadataSelectedModel,
    topicMetadataLocalModels,
    loadingTopicMetadataLocalModels,
    topicMetadataMode,
    setTopicMetadataMode,
    loadTopicMetadataLocalModels,
    showSimilarTopicsModal,
    setShowSimilarTopicsModal,
    searchingTopicId,
    setSearchingTopicId,
    similarTopics,
    setSimilarTopics,
    isSearchingSimilarTopics,
    setIsSearchingSimilarTopics,
    expandedTopics,
    setExpandedTopics,
  } = useTopicManagement({
    monthContents,
    setMonthContents,
    activeTab,
    meetingNote,
    meetingId,
    organizationId,
    setHasUnsavedChanges,
    setSavingStatus,
  });
  
  // エンティティ・リレーション管理（カスタムフック）
  const {
    topicEntities,
    setTopicEntities,
    topicRelations,
    setTopicRelations,
    isLoadingEntities,
    isLoadingRelations,
    pendingEntities,
    setPendingEntities,
    pendingRelations,
    setPendingRelations,
    replaceExistingEntities,
    setReplaceExistingEntities,
    showDeleteEntitiesModal,
    setShowDeleteEntitiesModal,
    showDeleteRelationsModal,
    setShowDeleteRelationsModal,
    showAddEntityModal,
    setShowAddEntityModal,
    showAddRelationModal,
    setShowAddRelationModal,
    editingEntity,
    setEditingEntity,
    editingRelation,
    setEditingRelation,
    entitySearchQuery,
    setEntitySearchQuery,
    relationSearchQuery,
    setRelationSearchQuery,
    entityTypeFilter,
    setEntityTypeFilter,
    relationTypeFilter,
    setRelationTypeFilter,
    bulkOperationMode,
    setBulkOperationMode,
    selectedEntityIds,
    setSelectedEntityIds,
    selectedRelationIds,
    setSelectedRelationIds,
    showMergeEntityModal,
    setShowMergeEntityModal,
    mergeSourceEntity,
    setMergeSourceEntity,
    showPathSearchModal,
    setShowPathSearchModal,
    showStatsModal,
    setShowStatsModal,
    isExporting,
    setIsExporting,
    exportSuccess,
    setExportSuccess,
  } = useEntityRelationManagement({
    showTopicModal,
    editingTopicId,
    organizationId,
    meetingId,
  });
  
  // ナビゲーションで展開されている議事録アイテムを管理（アイテムIDをキーとする）
  const [expandedNavItems, setExpandedNavItems] = useState<Set<string>>(new Set());
  
  // AI生成管理（カスタムフック）
  const {
    isAIGenerationModalOpen,
    setIsAIGenerationModalOpen,
    aiGenerationInput,
    setAIGenerationInput,
    selectedTopicIdsForAI,
    setSelectedTopicIdsForAI,
    selectedSummaryIdsForAI,
    setSelectedSummaryIdsForAI,
    isAIGenerating,
    setIsAIGenerating,
    aiSummaryFormat,
    setAiSummaryFormat,
    aiSummaryLength,
    setAiSummaryLength,
    aiCustomPrompt,
    setAiCustomPrompt,
    aiGeneratedContent,
    setAiGeneratedContent,
    originalContent,
    setOriginalContent,
    aiModelType,
    setAiModelType,
    aiSelectedModel,
    setAiSelectedModel,
    aiLocalModels,
    loadingAiLocalModels,
    availableAiModels,
    loadAiLocalModels,
    generateAISummary,
  } = useAIGeneration();


  // ページを離れる前の確認
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '保存されていない変更があります。このページを離れますか？';
        return e.returnValue;
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [hasUnsavedChanges]);

  // ローディングアニメーション用のスタイルを追加
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  // タブが切り替わったときに、activeSectionをcurrentSummaryIdにリセット
  // 注意: currentTabDataとcurrentSummaryIdは早期returnの後に計算されるため、
  // ここではmonthContentsとactiveTabを使用して計算する
  useEffect(() => {
    const currentTabData = monthContents[activeTab] as MonthContent | undefined;
    const currentSummaryId = currentTabData?.summaryId;
    if (currentSummaryId) {
      const isCurrentSectionAnItem = currentTabData?.items?.some(item => item.id === activeSection);
      // 現在のactiveSectionがアイテムIDでない場合、またはタブが切り替わった場合はリセット
      if (!isCurrentSectionAnItem || activeSection === 'summary') {
        setActiveSection(currentSummaryId);
      }
    }
  }, [activeTab, monthContents, activeSection, setActiveSection]);

  // topicIdパラメータから該当するトピックを見つけて表示
  useEffect(() => {
    if (!topicIdFromUrl || !monthContents || Object.keys(monthContents).length === 0) {
      return;
    }

    // すべてのタブとアイテムを検索して、該当するトピックを見つける
    for (const [tabKey, tabData] of Object.entries(monthContents)) {
      if (!tabData || !tabData.items) continue;
      
      for (const item of tabData.items) {
        if (!item.topics) continue;
        
        const foundTopic = item.topics.find(topic => topic.id === topicIdFromUrl);
        if (foundTopic) {
          // 該当するタブに切り替え
          setActiveTab(tabKey as TabType);
          // 該当するアイテムのセクションに設定
          setActiveSection(item.id);
          // ナビゲーションで展開
          setExpandedNavItems(prev => new Set([...prev, item.id]));
          // トピックを展開
          setExpandedTopics(prev => new Set([...prev, foundTopic.id]));
          
          // 少し遅延してからスクロール（DOMの更新を待つ）
          setTimeout(() => {
            const topicElementId = `${item.id}-topic-${foundTopic.id}`;
            const topicElement = document.getElementById(topicElementId);
            if (topicElement) {
              topicElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
              // ハイライト表示
              topicElement.style.backgroundColor = '#fff9e6';
              setTimeout(() => {
                topicElement.style.backgroundColor = '';
              }, 2000);
            }
          }, 300);
          
          // URLからtopicIdパラメータを削除（一度だけ実行）
          const newParams = new URLSearchParams(searchParams?.toString() || '');
          newParams.delete('topicId');
          const newUrl = newParams.toString() ? `?${newParams.toString()}` : '';
          router.replace(`/organization/meeting${newUrl}`, { scroll: false });
          
          return;
        }
      }
    }
  }, [topicIdFromUrl, monthContents, setActiveTab, setActiveSection, setExpandedNavItems, setExpandedTopics, searchParams, router]);

  // JSONダウンロード（カスタムフックのものを使用、downloadingJson状態を追加）
  const handleDownloadJson = useCallback(async () => {
    if (downloadingJson) return;
    setDownloadingJson(true);
    try {
      await handleDownloadJsonFromHook();
    } finally {
      setTimeout(() => setDownloadingJson(false), 500);
    }
  }, [handleDownloadJsonFromHook, downloadingJson]);

  
  // 議事録アイテムの削除確認モーダルを表示
  const handleDeleteItem = (tab: TabType, itemId: string) => {
    console.log('🗑️ [handleDeleteItem] 削除確認モーダルを表示:', { tab, itemId });
    setDeleteTargetTab(tab);
    setDeleteTargetItemId(itemId);
    setShowDeleteConfirmModal(true);
  };

  // 議事録アイテムの順番を上に移動
  const handleMoveItemUp = (tab: TabType, itemId: string) => {
    const tabData = monthContents[tab] as MonthContent | undefined;
    if (!tabData) return;

    const itemIndex = tabData.items.findIndex(i => i.id === itemId);
    if (itemIndex <= 0) return; // 最初のアイテムは上に移動できない

    setMonthContents(prev => {
      const updated = { ...prev };
      const currentTabData = updated[tab] as MonthContent | undefined;
      if (currentTabData) {
        const newItems = [...currentTabData.items];
        // 前のアイテムと入れ替え
        [newItems[itemIndex - 1], newItems[itemIndex]] = [newItems[itemIndex], newItems[itemIndex - 1]];
        updated[tab] = {
          ...currentTabData,
          items: newItems,
        };
      }
      return updated;
    });
    setHasUnsavedChanges(true);
  };

  // 議事録アイテムの順番を下に移動
  const handleMoveItemDown = (tab: TabType, itemId: string) => {
    const tabData = monthContents[tab] as MonthContent | undefined;
    if (!tabData) return;

    const itemIndex = tabData.items.findIndex(i => i.id === itemId);
    if (itemIndex < 0 || itemIndex >= tabData.items.length - 1) return; // 最後のアイテムは下に移動できない

    setMonthContents(prev => {
      const updated = { ...prev };
      const currentTabData = updated[tab] as MonthContent | undefined;
      if (currentTabData) {
        const newItems = [...currentTabData.items];
        // 次のアイテムと入れ替え
        [newItems[itemIndex], newItems[itemIndex + 1]] = [newItems[itemIndex + 1], newItems[itemIndex]];
        updated[tab] = {
          ...currentTabData,
          items: newItems,
        };
      }
      return updated;
    });
    setHasUnsavedChanges(true);
  };
  
  // 議事録アイテムの削除実行
  const confirmDeleteItem = async () => {
    if (!deleteTargetTab || !deleteTargetItemId) {
      devWarn('⚠️ [confirmDeleteItem] 削除対象が設定されていません');
      return;
    }
    
    const tab = deleteTargetTab;
    const itemId = deleteTargetItemId;
    
    devLog('✅ [confirmDeleteItem] 削除実行開始:', { tab, itemId });
    
    // モーダルを閉じる
    setShowDeleteConfirmModal(false);
    setDeleteTargetTab(null);
    setDeleteTargetItemId(null);
    
    let updatedContents: typeof monthContents = monthContents;
    setMonthContents(prev => {
      devLog('📝 [confirmDeleteItem] 状態更新前:', { 
        prevItems: (prev[tab] as MonthContent | undefined)?.items?.length || 0,
        itemId 
      });
      const updated = { ...prev };
      const tabData = updated[tab] as MonthContent | undefined;
      if (tabData) {
        const beforeCount = tabData.items.length;
        updated[tab] = {
          ...tabData,
          items: tabData.items.filter(i => i.id !== itemId),
        };
        const afterCount = (updated[tab] as MonthContent).items.length;
        devLog('📝 [confirmDeleteItem] 状態更新後:', { 
          beforeCount, 
          afterCount,
          deleted: beforeCount > afterCount
        });
      } else {
        devWarn('⚠️ [confirmDeleteItem] tabDataが見つかりません:', { tab });
      }
      updatedContents = updated;
      return updated;
    });
    
    // 削除されたアイテムが現在選択されている場合は、summaryに戻す
    if (activeSection === itemId && currentSummaryId) {
      devLog('🔄 [confirmDeleteItem] activeSectionをsummaryに変更');
      setActiveSection(currentSummaryId);
    }
    
    // 編集モードをキャンセル
    if (editingSection === itemId || editingSection === `${itemId}-title`) {
        devLog('🔄 [confirmDeleteItem] 編集モードをキャンセル');
      handleCancelEdit();
    }
    
    setHasUnsavedChanges(true); // 未保存の変更があることを記録
    
    // JSONファイルに自動保存
    if (meetingNote && updatedContents) {
      try {
        devLog('💾 [confirmDeleteItem] 保存開始...');
        const contentJson = JSON.stringify(updatedContents, null, 2);
        // 事業会社の管理はorganizationsテーブルのtypeカラムで行うため、通常のsaveMeetingNoteを使用
        await saveMeetingNote({
          ...meetingNote,
          content: contentJson,
        });
        devLog('✅ [confirmDeleteItem] 自動保存成功');
        setHasUnsavedChanges(false); // 保存完了後、未保存フラグをリセット
      } catch (error: any) {
        console.error('❌ [confirmDeleteItem] 自動保存に失敗しました:', error);
        // エラーは警告のみで続行（未保存フラグはtrueのまま）
      }
    } else {
      devWarn('⚠️ [confirmDeleteItem] 保存スキップ:', { 
        hasMeetingNote: !!meetingNote, 
        hasUpdatedContents: updatedContents !== undefined 
      });
    }
  };
  
  // 削除確認モーダルをキャンセル
  const cancelDeleteItem = () => {
    devLog('🗑️ [cancelDeleteItem] 削除をキャンセルしました');
    setShowDeleteConfirmModal(false);
    setDeleteTargetTab(null);
    setDeleteTargetItemId(null);
  };
  
  // トピック削除確認モーダルを表示
  // 追加処理中のフラグ（重複実行を防ぐ）
  const isAddingItemRef = useRef(false);
  const [isAddingItem, setIsAddingItem] = useState(false);

  // タブの順番を変更する関数（早期リターンの前に定義）
  const handleMoveTabUp = useCallback((tabId: TabType) => {
    setTabOrder(prevOrder => {
      const index = prevOrder.indexOf(tabId);
      if (index > 0) {
        const newOrder = [...prevOrder];
        const [movedTab] = newOrder.splice(index, 1);
        newOrder.splice(index - 1, 0, movedTab);
        setHasUnsavedChanges(true);
        return newOrder;
      }
      return prevOrder;
    });
  }, [setHasUnsavedChanges]);

  const handleMoveTabDown = useCallback((tabId: TabType) => {
    setTabOrder(prevOrder => {
      const index = prevOrder.indexOf(tabId);
      if (index < prevOrder.length - 1) {
        const newOrder = [...prevOrder];
        const [movedTab] = newOrder.splice(index, 1);
        newOrder.splice(index + 1, 0, movedTab);
        setHasUnsavedChanges(true);
        return newOrder;
      }
      return prevOrder;
    });
  }, [setHasUnsavedChanges]);

  // 目次データを集計する関数（早期リターンの前に定義）
  const getTableOfContentsData = useCallback(() => {
    const tocData: Array<{
      tabId: TabType;
      tabLabel: string;
      itemCount: number;
      topicCount: number;
      items: Array<{
        id: string;
        title: string;
        topicCount: number;
      }>;
      isSummaryTab: boolean;
    }> = [];

    // tabOrderに基づいてタブを並べ替え
    tabOrder.forEach((tabId) => {
      const monthData = monthContents[tabId] as MonthContent | undefined;
      const items = monthData?.items || [];
      let totalTopicCount = 0;
      
      const itemData = items.map((item) => {
        const topicCount = item.topics?.length || 0;
        totalTopicCount += topicCount;
        return {
          id: item.id,
          title: item.title || '無題',
          topicCount,
        };
      });

      const isSummaryTab = SUMMARY_TABS.some(t => t.id === tabId);
      const month = MONTHS.find(m => m.id === tabId);
      const summaryTab = SUMMARY_TABS.find(t => t.id === tabId);

      tocData.push({
        tabId,
        tabLabel: customTabLabels[tabId] || month?.label || summaryTab?.label || tabId,
        itemCount: items.length,
        topicCount: totalTopicCount,
        items: itemData,
        isSummaryTab,
      });
    });

    return tocData;
  }, [tabOrder, monthContents, customTabLabels]);

  // 新しい議事録アイテムを追加
  const handleAddItem = useCallback(async (tab: TabType, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    // 既に追加処理中の場合は何もしない
    if (isAddingItemRef.current) {
      devLog('追加処理中のためスキップ');
      return;
    }
    
    isAddingItemRef.current = true;
    setIsAddingItem(true);
    
    const newItemId = generateUniqueId();
    
    // 状態を更新（新しいオブジェクトを作成して不変性を保つ）
    const updated = { ...monthContents };
    if (!updated[tab] || typeof updated[tab] === 'string') {
      updated[tab] = { summary: '', items: [] };
    }
    const tabData = updated[tab] as MonthContent;
    updated[tab] = {
      ...tabData,
      items: [...tabData.items, {
        id: newItemId,
        title: '新しい議事録',
        content: '',
      }],
    };
    
    // 状態を更新
    setMonthContents(updated);
    setHasUnsavedChanges(true); // 未保存の変更があることを記録
    
    // 追加したアイテムを選択状態にして内容編集モードにする
    setActiveSection(newItemId);
    setEditingMonth(tab);
    setEditingSection(newItemId); // 内容編集モード（タイトル編集モードではなく）
    setEditingContent(''); // 空の内容から開始
    setEditingItemTitle('新しい議事録');
    
    // JSONファイルに自動保存
    if (meetingNote) {
      try {
        // 状態更新を確実にするため、少し待ってから保存
        await new Promise(resolve => setTimeout(resolve, 50));
        
        const contentJson = JSON.stringify(updated, null, 2);
        // 事業会社の管理はorganizationsテーブルのtypeカラムで行うため、通常のsaveMeetingNoteを使用
        await saveMeetingNote({
          ...meetingNote,
          content: contentJson,
        });
        devLog('✅ [handleAddItem] 自動保存成功');
        setHasUnsavedChanges(false); // 保存完了後、未保存フラグをリセット
      } catch (error: any) {
        console.error('❌ [handleAddItem] 自動保存に失敗しました:', error);
        // エラーは警告のみで続行（未保存フラグはtrueのまま）
      }
    }
    
    // 少し遅延してからフラグをリセット（連続クリックを防ぐ）
    setTimeout(() => {
      isAddingItemRef.current = false;
      setIsAddingItem(false);
    }, 300);
  }, [meetingNote, monthContents, setMonthContents, setActiveSection, setEditingMonth, setEditingSection, setEditingContent, setEditingItemTitle, setHasUnsavedChanges]);

  if (loading) {
    return (
      <Layout>
        <div style={{ padding: '40px', textAlign: 'center' }}>
          <p>読み込み中...</p>
        </div>
      </Layout>
    );
  }

  if (error || !meetingNote) {
    return (
      <Layout>
        <div style={{ padding: '40px' }}>
          <h2 style={{ marginBottom: '8px' }}>議事録詳細</h2>
          <p style={{ color: 'var(--color-error)' }}>
            {error || 'データが見つかりませんでした。'}
          </p>
          <button
            onClick={async () => {
              if (hasUnsavedChanges) {
                const { tauriConfirm } = await import('@/lib/orgApi');
                const confirmed = await tauriConfirm('保存されていない変更があります。このページを離れますか？', 'ページを離れる確認');
                if (!confirmed) {
                  return;
                }
              }
              router.push(`/organization/detail?id=${organizationId}&tab=meetingNotes`);
            }}
            style={{
              marginTop: '16px',
              padding: '8px 16px',
              backgroundColor: 'var(--color-primary)',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px',
            }}
          >
            組織ページに戻る
          </button>
        </div>
      </Layout>
    );
  }

  const currentTabData = monthContents[activeTab] as MonthContent | undefined;
  const isSummaryTab = SUMMARY_TABS.some(t => t.id === activeTab);
  const currentSummaryId = currentTabData?.summaryId;

  return (
    <Layout>
      <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto', backgroundColor: '#F9FAFB', minHeight: '100vh' }}>
        {/* ヘッダー */}
        <HeaderSection
          title={meetingNote.title}
          savingStatus={savingStatus}
          downloadingJson={downloadingJson}
          downloadingHtml={downloadingHtml}
          hasUnsavedChanges={hasUnsavedChanges}
          organizationId={organizationId}
          allOrganizations={allOrganizations}
          onSave={async () => {
            // tabOrderも含めて保存
            if (meetingNote) {
              try {
                setSavingStatus('saving');
                const dataToSave: MeetingNoteData & { 
                  customTabLabels?: Record<TabType, string | undefined>;
                  tabOrder?: TabType[];
                } = {
                  ...monthContents,
                  customTabLabels,
                  tabOrder,
                };
                const updatedNote: MeetingNote = {
                  ...meetingNote,
                  content: JSON.stringify(dataToSave),
                };
                await saveMeetingNote(updatedNote);
                setHasUnsavedChanges(false);
                setSavingStatus('saved');
                setTimeout(() => {
                  setSavingStatus('idle');
                }, 2000);
              } catch (err: any) {
                console.error('保存エラー:', err);
                alert(`保存に失敗しました: ${err.message || '不明なエラー'}`);
                setSavingStatus('idle');
              }
            } else {
              await handleManualSave();
            }
          }}
          onDownloadJson={handleDownloadJson}
          onDownloadHtml={handleDownloadHtmlFromHook}
          onOrganizationChange={handleOrganizationChange}
        />

        {/* タブナビゲーション */}
        <TabNavigation
          activeTab={activeTab}
          customTabLabels={customTabLabels}
          monthContents={monthContents}
          tabOrder={tabOrder}
          onSetActiveTab={setActiveTab}
          onSetActiveSection={setActiveSection}
          onShowTableOfContents={() => setShowTableOfContentsModal(true)}
        />

        {/* 目次モーダル */}
        <TableOfContentsModal
          isOpen={showTableOfContentsModal}
          onClose={() => setShowTableOfContentsModal(false)}
          getTableOfContentsData={getTableOfContentsData}
          monthContents={monthContents}
          customTabLabels={customTabLabels}
          editingTabLabel={editingTabLabel}
          editingTabLabelValue={editingTabLabelValue}
          expandedMonthInTOC={expandedMonthInTOC}
          onSetEditingTabLabel={setEditingTabLabel}
          onSetEditingTabLabelValue={setEditingTabLabelValue}
          onSetCustomTabLabels={setCustomTabLabels}
          onSetHasUnsavedChanges={setHasUnsavedChanges}
          onSetExpandedMonthInTOC={setExpandedMonthInTOC}
          onSetActiveTab={setActiveTab}
          onSetActiveSection={setActiveSection}
          onMoveTabUp={handleMoveTabUp}
          onMoveTabDown={handleMoveTabDown}
        />


        {/* コンテンツレイアウト */}
        <div style={{ display: 'flex', gap: '28px', marginTop: '24px' }}>
          {/* メインコンテンツ */}
          <main style={{
            flex: '1 1 0',
            minWidth: 0,
            maxWidth: 'calc(100% - 328px)',
            backgroundColor: '#FFFFFF',
            padding: '40px 36px 36px 36px',
            borderRadius: '14px',
            minHeight: '350px',
            boxShadow: '0 4px 16px rgba(15, 23, 42, 0.08), 0 1px 4px rgba(0, 0, 0, 0.04)',
            border: '1px solid #E5E7EB',
            overflow: 'hidden',
          }}>
            {isSummaryTab ? (
              <div>
                <h2 style={{
                  marginTop: 0,
                  fontSize: '2.1em',
                  borderBottom: '4px solid #0066CC',
                  paddingBottom: '18px',
                  marginBottom: '36px',
                  color: '#0F172A',
                  letterSpacing: '0.8px',
                  fontWeight: '800',
                  lineHeight: '1.3',
                  textShadow: '0 1px 2px rgba(0, 0, 0, 0.05)',
                }}>
                  {SUMMARY_TABS.find(t => t.id === activeTab)?.label}
                </h2>
                
                {/* 総括サマリ */}
                <SummaryContentSection
                  activeTab={activeTab}
                  activeSection={activeSection}
                  currentSummaryId={currentSummaryId}
                  currentTabData={currentTabData}
                  customTabLabels={customTabLabels}
                  editingMonth={editingMonth}
                  editingSection={editingSection}
                  editingContent={editingContent}
                  onSetEditingContent={setEditingContent}
                  onSaveEdit={handleSaveEdit}
                  onCancelEdit={handleCancelEdit}
                  onStartEditSummary={handleStartEditSummary}
                  onOpenAIGenerationModal={() => {
                    setAIGenerationInput('');
                    setSelectedTopicIdsForAI([]);
                    setSelectedSummaryIdsForAI([]);
                    setAiSummaryFormat('auto');
                    setAiSummaryLength(500);
                    setAiCustomPrompt('');
                    setIsAIGenerationModalOpen(true);
                  }}
                />
                
                {/* 議事録アイテム */}
                <div style={{ marginBottom: '32px' }}>
                  {currentTabData?.items && currentTabData.items.length > 0 && activeSection !== currentSummaryId ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                      {currentTabData.items
                        .filter((item) => activeSection === item.id)
                        .map((item) => (
                          <MeetingItemCard
                            key={item.id}
                            item={item}
                            activeTab={activeTab}
                            editingMonth={editingMonth}
                            editingSection={editingSection}
                            editingItemTitle={editingItemTitle}
                            editingContent={editingContent}
                            editingItemDate={editingItemDate}
                            editingItemTime={editingItemTime}
                            expandedTopics={expandedTopics}
                            onSetEditingItemTitle={setEditingItemTitle}
                            onSetEditingContent={setEditingContent}
                            onSetEditingItemDate={setEditingItemDate}
                            onSetEditingItemTime={setEditingItemTime}
                            onSetEditingMonth={setEditingMonth}
                            onSetEditingSection={setEditingSection}
                            onSetExpandedTopics={setExpandedTopics}
                            onStartEditItem={handleStartEditItem}
                            onStartEditItemTitle={handleStartEditItemTitle}
                            onSaveEdit={handleSaveEdit}
                            onCancelEdit={handleCancelEdit}
                            onDeleteItem={handleDeleteItem}
                            monthContents={monthContents}
                            onSetMonthContents={setMonthContents}
                            onSetHasUnsavedChanges={setHasUnsavedChanges}
                            organizationId={organizationId}
                            meetingId={meetingId}
                            onSetEditingTopicItemId={setEditingTopicItemId}
                            onSetEditingTopicId={setEditingTopicId}
                            editingTopicId={editingTopicId}
                            onSetTopicTitle={setTopicTitle}
                            onSetTopicContent={setTopicContent}
                            onSetTopicSemanticCategory={setTopicSemanticCategory}
                            onSetTopicKeywords={setTopicKeywords}
                            onSetTopicSummary={setTopicSummary}
                            onSetTopicImportance={setTopicImportance}
                            onSetShowTopicModal={setShowTopicModal}
                            onDeleteTopic={handleDeleteTopic}
                          />
                        ))}
                    </div>
                  ) : activeSection !== 'summary' && (!currentTabData?.items || currentTabData.items.length === 0) ? (
                    <div style={{
                      padding: '48px 40px',
                      textAlign: 'center',
                      background: 'linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%)',
                      borderRadius: '12px',
                      border: '2px dashed #CBD5E1',
                    }}>
                      <p style={{ margin: 0, color: '#64748B', fontSize: '15px', lineHeight: '1.6' }}>
                        議事録がありません。「+ 追加」ボタンから追加してください。
                      </p>
                    </div>
                  ) : null}
                </div>
              </div>
            ) : (
              <div>
                <h2 style={{
                  marginTop: 0,
                  fontSize: '2.1em',
                  borderBottom: '4px solid #0066CC',
                  paddingBottom: '18px',
                  marginBottom: '36px',
                  color: '#0F172A',
                  letterSpacing: '0.8px',
                  fontWeight: '800',
                  lineHeight: '1.3',
                  textShadow: '0 1px 2px rgba(0, 0, 0, 0.05)',
                }}>
                  {customTabLabels[activeTab] || MONTHS.find(m => m.id === activeTab)?.label}
                </h2>
                
                {/* 月サマリ */}
                <MonthSummarySection
                  activeTab={activeTab}
                  activeSection={activeSection}
                  currentSummaryId={currentSummaryId}
                  currentTabData={currentTabData}
                  customTabLabels={customTabLabels}
                  editingMonth={editingMonth}
                  editingSection={editingSection}
                  editingContent={editingContent}
                  onSetEditingContent={setEditingContent}
                  onSaveEdit={handleSaveEdit}
                  onCancelEdit={handleCancelEdit}
                  onStartEditSummary={handleStartEditSummary}
                  onOpenAIGenerationModal={() => {
                    setAIGenerationInput('');
                    setSelectedTopicIdsForAI([]);
                    setSelectedSummaryIdsForAI([]);
                    setAiSummaryFormat('auto');
                    setAiSummaryLength(500);
                    setAiCustomPrompt('');
                    setIsAIGenerationModalOpen(true);
                  }}
                />
                
                {/* 議事録アイテム */}
                <div style={{ marginBottom: '32px' }}>
                  {currentTabData?.items && currentTabData.items.length > 0 && activeSection !== currentSummaryId ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                      {currentTabData.items
                        .filter((item) => activeSection === item.id)
                        .map((item) => (
                          <MeetingItemCard
                            key={item.id}
                            item={item}
                            activeTab={activeTab}
                            editingMonth={editingMonth}
                            editingSection={editingSection}
                            editingItemTitle={editingItemTitle}
                            editingContent={editingContent}
                            editingItemDate={editingItemDate}
                            editingItemTime={editingItemTime}
                            expandedTopics={expandedTopics}
                            onSetEditingItemTitle={setEditingItemTitle}
                            onSetEditingContent={setEditingContent}
                            onSetEditingItemDate={setEditingItemDate}
                            onSetEditingItemTime={setEditingItemTime}
                            onSetEditingMonth={setEditingMonth}
                            onSetEditingSection={setEditingSection}
                            onSetExpandedTopics={setExpandedTopics}
                            onStartEditItem={handleStartEditItem}
                            onStartEditItemTitle={handleStartEditItemTitle}
                            onSaveEdit={handleSaveEdit}
                            onCancelEdit={handleCancelEdit}
                            onDeleteItem={handleDeleteItem}
                            monthContents={monthContents}
                            onSetMonthContents={setMonthContents}
                            onSetHasUnsavedChanges={setHasUnsavedChanges}
                            organizationId={organizationId}
                            meetingId={meetingId}
                            onSetEditingTopicItemId={setEditingTopicItemId}
                            onSetEditingTopicId={setEditingTopicId}
                            editingTopicId={editingTopicId}
                            onSetTopicTitle={setTopicTitle}
                            onSetTopicContent={setTopicContent}
                            onSetTopicSemanticCategory={setTopicSemanticCategory}
                            onSetTopicKeywords={setTopicKeywords}
                            onSetTopicSummary={setTopicSummary}
                            onSetTopicImportance={setTopicImportance}
                            onSetShowTopicModal={setShowTopicModal}
                            onDeleteTopic={handleDeleteTopic}
                          />
                        ))}
                    </div>
                  ) : activeSection !== currentSummaryId && (!currentTabData?.items || currentTabData.items.length === 0) ? (
                    <div style={{
                      padding: '48px 40px',
                      textAlign: 'center',
                      background: 'linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%)',
                      borderRadius: '12px',
                      border: '2px dashed #CBD5E1',
                    }}>
                      <p style={{ margin: 0, color: '#64748B', fontSize: '15px', lineHeight: '1.6' }}>
                        議事録がありません。「+ 追加」ボタンから追加してください。
                      </p>
                    </div>
                  ) : null}
                </div>
              </div>
            )}
          </main>
          
          {/* サイドバー */}
          <SidebarSection
            currentTabData={currentTabData}
            activeSection={activeSection}
            currentSummaryId={currentSummaryId}
            expandedNavItems={expandedNavItems}
            activeTab={activeTab}
            meetingId={meetingId}
            isAddingItem={isAddingItem}
            onSetActiveSection={setActiveSection}
            onSetExpandedNavItems={setExpandedNavItems}
            onAddItem={handleAddItem}
            onMoveItemUp={handleMoveItemUp}
            onMoveItemDown={handleMoveItemDown}
          />
        </div>
      </div>
      
      {/* 議事録アイテム削除確認モーダル */}
      <DeleteItemConfirmModal
        isOpen={showDeleteConfirmModal}
        deleteTargetTab={deleteTargetTab}
        deleteTargetItemId={deleteTargetItemId}
        monthContents={monthContents}
        onConfirm={confirmDeleteItem}
        onCancel={cancelDeleteItem}
      />
      
      {/* トピック削除確認モーダル */}
      <DeleteTopicConfirmModal
        isOpen={showDeleteTopicModal}
        activeTab={activeTab}
        deleteTargetTopicItemId={deleteTargetTopicItemId}
        deleteTargetTopicId={deleteTargetTopicId}
        monthContents={monthContents}
        onConfirm={confirmDeleteTopic}
        onCancel={cancelDeleteTopic}
      />
      
      {/* エンティティ一括削除確認モーダル */}
      <DeleteEntitiesConfirmModal
        isOpen={showDeleteEntitiesModal}
        entities={(pendingEntities && pendingEntities.length > 0) ? pendingEntities : topicEntities}
        onConfirm={async () => {
          setShowDeleteEntitiesModal(false);
          try {
            const entitiesToDelete = (pendingEntities && pendingEntities.length > 0) ? pendingEntities : topicEntities;
            for (const entity of entitiesToDelete) {
              try {
                await deleteEntity(entity.id);
                devLog(`✅ エンティティを削除しました: ${entity.id}`);
              } catch (error: any) {
                devWarn(`⚠️ エンティティ削除エラー: ${entity.id}`, error);
              }
            }
            // pendingEntitiesの場合はクリア、topicEntitiesの場合は再読み込み
            if (pendingEntities && pendingEntities.length > 0) {
              setPendingEntities([]);
            } else {
              // トピックに関連するエンティティを再読み込み
              const entities = await getEntitiesByOrganizationId(organizationId);
              const topicEmbeddingId = `${meetingId}-topic-${editingTopicId}`;
              const filteredEntities = entities.filter(e => 
                e.metadata && typeof e.metadata === 'object' && 'topicId' in e.metadata && e.metadata.topicId === editingTopicId
              );
              setTopicEntities(filteredEntities);
            }
            alert('エンティティを削除しました');
          } catch (error: any) {
            console.error('❌ エンティティ一括削除エラー:', error);
            alert(`エンティティの削除に失敗しました: ${error?.message || '不明なエラー'}`);
          }
        }}
        onCancel={() => setShowDeleteEntitiesModal(false)}
      />
      
      {/* リレーション一括削除確認モーダル */}
      <DeleteRelationsConfirmModal
        isOpen={showDeleteRelationsModal}
        relations={(pendingRelations && pendingRelations.length > 0) ? pendingRelations : topicRelations}
        entities={(pendingEntities && pendingEntities.length > 0) ? pendingEntities : topicEntities}
        onConfirm={async () => {
          setShowDeleteRelationsModal(false);
          try {
            const topicEmbeddingId = `${meetingId}-topic-${editingTopicId}`;
            const relationsToDelete = (pendingRelations && pendingRelations.length > 0) 
              ? pendingRelations 
              : topicRelations;
            
            for (const relation of relationsToDelete) {
              try {
                await deleteRelation(relation.id);
                devLog(`✅ リレーションを削除しました: ${relation.id}`);
              } catch (error: any) {
                devWarn(`⚠️ リレーション削除エラー: ${relation.id}`, error);
              }
            }
            
            // pendingRelationsの場合はクリア、topicRelationsの場合は再読み込み
            if (pendingRelations && pendingRelations.length > 0) {
              setPendingRelations([]);
            } else {
              // トピックに関連するリレーションを再読み込み
              const relations = await getRelationsByTopicId(topicEmbeddingId);
              setTopicRelations(relations);
            }
            alert('リレーションを削除しました');
          } catch (error: any) {
            console.error('❌ リレーション一括削除エラー:', error);
            alert(`リレーションの削除に失敗しました: ${error?.message || '不明なエラー'}`);
          }
        }}
        onCancel={() => setShowDeleteRelationsModal(false)}
      />
      
      {/* 個別トピック追加・編集モーダル */}
      <TopicModal
        isOpen={showTopicModal}
        editingTopicId={editingTopicId}
        editingTopicItemId={editingTopicItemId}
        topicTitle={topicTitle}
        topicContent={topicContent}
        topicSemanticCategory={topicSemanticCategory}
        topicKeywords={topicKeywords}
        topicSummary={topicSummary}
        topicImportance={topicImportance}
        pendingMetadata={pendingMetadata}
        pendingEntities={pendingEntities}
        pendingRelations={pendingRelations}
        topicEntities={topicEntities}
        topicRelations={topicRelations}
        replaceExistingEntities={replaceExistingEntities}
        isGeneratingMetadata={isGeneratingMetadata}
        topicMetadataModelType={topicMetadataModelType}
        topicMetadataSelectedModel={topicMetadataSelectedModel}
        topicMetadataLocalModels={topicMetadataLocalModels}
        loadingTopicMetadataLocalModels={loadingTopicMetadataLocalModels}
        topicMetadataMode={topicMetadataMode}
        isLoadingEntities={isLoadingEntities}
        isLoadingRelations={isLoadingRelations}
        entitySearchQuery={entitySearchQuery}
        entityTypeFilter={entityTypeFilter}
        relationTypeLabels={RELATION_TYPE_LABELS}
        entityTypeLabels={ENTITY_TYPE_LABELS}
        activeTab={activeTab}
        monthContents={monthContents}
        organizationId={organizationId}
        meetingId={meetingId}
        onClose={() => {
          setShowTopicModal(false);
          setEditingTopicItemId(null);
          setEditingTopicId(null);
          setTopicTitle('');
          setTopicContent('');
          setTopicSemanticCategory('');
          setTopicKeywords('');
          setTopicSummary('');
          setTopicImportance('');
          setPendingMetadata(null);
          setPendingEntities(null);
          setPendingRelations(null);
          setTopicEntities([]);
          setTopicRelations([]);
          setReplaceExistingEntities(false);
        }}
        onSave={async (updatedContents) => {
          try {
            setSavingStatus('saving');
            
            // トピック情報を取得
            const topicId = editingTopicId || (() => {
              // 新規追加の場合は、保存されたトピックIDを取得
              const tabData = updatedContents[activeTab];
              if (tabData?.items) {
                const item = tabData.items.find(i => i.id === editingTopicItemId);
                if (item?.topics && item.topics.length > 0) {
                  // 最新のトピック（最後に追加されたもの）を取得
                  return item.topics[item.topics.length - 1]?.id;
                }
              }
              return null;
            })();
            
            if (!topicId) {
              console.error('❌ トピックIDが取得できませんでした');
              alert('エラー: トピックIDが取得できませんでした');
              setSavingStatus('idle');
              return;
            }
            
            // トピック情報を取得
            const tabData = updatedContents[activeTab];
            const item = tabData?.items?.find(i => i.id === editingTopicItemId);
            const topic = item?.topics?.find(t => t.id === topicId);
            
            if (!topic) {
              console.error('❌ トピックが見つかりませんでした');
              alert('エラー: トピックが見つかりませんでした');
              setSavingStatus('idle');
              return;
            }
            
            // 議事録を保存
            if (meetingNote) {
              const contentJson = JSON.stringify(updatedContents, null, 2);
              await saveMeetingNote({
                ...meetingNote,
                content: contentJson,
              });
              devLog('✅ 議事録を保存しました');
            }
            
            // トピック埋め込みを保存（非同期）
            if (meetingNote && organizationId) {
              // topicDateを取得（mentionedDateまたはitem.dateから）
              const topicDate = (topic as any).mentionedDate !== undefined 
                ? (topic as any).mentionedDate 
                : (item?.date || undefined);
              
              saveTopicEmbeddingAsync(
                topicId,
                meetingId,
                organizationId,
                topic.title || '',
                topic.content || '',
                {
                  keywords: topic.keywords,
                  semanticCategory: topic.semanticCategory,
                  importance: topic.importance,
                  summary: topic.summary,
                },
                undefined, // regulationId
                topicDate
              ).catch((error: any) => {
                devWarn('⚠️ トピック埋め込みの保存に失敗しました（続行します）:', error);
              });
            }
            
            // topicsレコードを作成または確認
            const topicEmbeddingId = `${meetingId}-topic-${topicId}`;
            try {
              const topicEmbeddingResult = await callTauriCommand('doc_get', {
                collectionName: 'topics',
                docId: topicEmbeddingId,
              });
              
              if (!topicEmbeddingResult || !topicEmbeddingResult.exists || !topicEmbeddingResult.data) {
                // レコードが存在しない場合は作成
                const now = new Date().toISOString();
                await callTauriCommand('doc_set', {
                  collectionName: 'topics',
                  docId: topicEmbeddingId,
                  data: {
                    id: topicEmbeddingId,
                    topicId: topicId,
                    meetingNoteId: meetingId,
                    organizationId: organizationId,
                    title: topic.title || '',
                    content: topic.content || '',
                    createdAt: now,
                    updatedAt: now,
                  },
                });
                devLog('✅ topicsレコードを作成しました:', topicEmbeddingId);
              }
            } catch (error: any) {
              const errorMessage = error?.message || error?.error || error?.errorString || String(error || '');
              const isNoRowsError = errorMessage.includes('no rows') || 
                                    errorMessage.includes('Query returned no rows') ||
                                    errorMessage.includes('ドキュメント取得エラー');
              
              if (isNoRowsError) {
                // レコードが存在しない場合は作成
                const now = new Date().toISOString();
                try {
                  await callTauriCommand('doc_set', {
                    collectionName: 'topics',
                    docId: topicEmbeddingId,
                    data: {
                      id: topicEmbeddingId,
                      topicId: topicId,
                      meetingNoteId: meetingId,
                      organizationId: organizationId,
                      title: topic.title || '',
                      content: topic.content || '',
                      createdAt: now,
                      updatedAt: now,
                    },
                  });
                  devLog('✅ topicsレコードを作成しました:', topicEmbeddingId);
                } catch (createError: any) {
                  devWarn('⚠️ topicsレコード作成エラー（続行します）:', createError);
                }
              } else {
                devWarn('⚠️ topicsレコード確認エラー（続行します）:', error);
              }
            }
            
            // 既存のエンティティとリレーションを削除（上書き保存の場合）
            if (replaceExistingEntities && topicId) {
              try {
                // 既存のリレーションを削除
                const existingRelations = await getRelationsByTopicId(topicEmbeddingId);
                for (const relation of existingRelations) {
                  try {
                    await deleteRelation(relation.id);
                    devLog(`✅ 既存のリレーションを削除しました: ${relation.id}`);
                  } catch (error: any) {
                    devWarn(`⚠️ リレーション削除エラー（続行します）: ${relation.id}`, error);
                  }
                }
                
                // 既存のエンティティを削除（同じトピック内のもののみ）
                const allEntities = meetingNote?.companyId
                  ? await getEntitiesByCompanyId(meetingNote.companyId)
                  : await getEntitiesByOrganizationId(organizationId);
                const entitiesInTopic = allEntities.filter(e => {
                  if (!e.metadata || typeof e.metadata !== 'object') return false;
                  return 'topicId' in e.metadata && e.metadata.topicId === topicId;
                });
                
                for (const entity of entitiesInTopic) {
                  try {
                    await deleteEntity(entity.id);
                    devLog(`✅ 既存のエンティティを削除しました: ${entity.id}`);
                  } catch (error: any) {
                    devWarn(`⚠️ エンティティ削除エラー（続行します）: ${entity.id}`, error);
                  }
                }
              } catch (error: any) {
                devWarn('⚠️ 既存データの削除エラー（続行します）:', error);
              }
            }
            
            // エンティティを保存
            const entitiesToSave = pendingEntities && pendingEntities.length > 0 ? pendingEntities : topicEntities;
            const pendingIdToCreatedIdMap = new Map<string, string>();
            
            if (entitiesToSave && entitiesToSave.length > 0) {
              devLog('💾 エンティティ保存を開始:', entitiesToSave.length, '件');
              
              // 既存のエンティティを取得（重複チェック用）
              const allEntities = meetingNote?.companyId
                ? await getEntitiesByCompanyId(meetingNote.companyId)
                : await getEntitiesByOrganizationId(organizationId);
              
              // 同じトピック内で既に存在するエンティティをフィルタリング
              const existingEntitiesInTopic = allEntities.filter(e => {
                if (!e.metadata || typeof e.metadata !== 'object') return false;
                return 'topicId' in e.metadata && e.metadata.topicId === topicId;
              });
              
              // 名前 + topicIdの組み合わせで重複チェック
              const existingEntityKeys = new Set(
                existingEntitiesInTopic.map(e => `${e.name.toLowerCase()}_${topicId}`)
              );
              
              // 重複しないエンティティのみを作成
              const entitiesToCreate = entitiesToSave.filter(entity => {
                const key = `${entity.name.toLowerCase()}_${topicId}`;
                return !existingEntityKeys.has(key);
              });
              
              devLog(`📊 エンティティ保存対象: ${entitiesToCreate.length}件（重複除外: ${entitiesToSave.length - entitiesToCreate.length}件）`);
              
              for (const entity of entitiesToCreate) {
                try {
                  const pendingId = entity.id;
                  
                  // metadataにtopicIdを確実に設定
                  const entityMetadata = {
                    ...(entity.metadata || {}),
                    topicId: topicId,
                  };
                  
                  // organizationIdとcompanyIdを確実に設定
                  const companyId = entity.companyId || meetingNote?.companyId || undefined;
                  const orgId = companyId 
                    ? (entity.organizationId || organizationId || undefined)
                    : (entity.organizationId || organizationId);
                  
                  if (!orgId && !companyId) {
                    throw new Error('organizationIdまたはcompanyIdが設定されていません');
                  }
                  
                  const createdEntity = await createEntity({
                    name: entity.name,
                    type: entity.type,
                    aliases: entity.aliases || [],
                    metadata: entityMetadata,
                    organizationId: orgId,
                    companyId: companyId,
                  });
                  
                  pendingIdToCreatedIdMap.set(pendingId, createdEntity.id);
                  devLog(`✅ エンティティ作成成功: ${entity.name} (${createdEntity.id})`);
                } catch (error: any) {
                  console.error('❌ エンティティ作成エラー:', {
                    entityName: entity.name,
                    error: error?.message || error,
                  });
                  throw new Error(`エンティティ「${entity.name}」の作成に失敗しました: ${error?.message || error}`);
                }
              }
              
              // 既存のエンティティもマッピングに追加
              existingEntitiesInTopic.forEach(entity => {
                const entityToMatch = entitiesToSave.find(e => 
                  e.name.toLowerCase() === entity.name.toLowerCase() &&
                  e.metadata && typeof e.metadata === 'object' &&
                  'topicId' in e.metadata && e.metadata.topicId === topicId
                );
                if (entityToMatch) {
                  pendingIdToCreatedIdMap.set(entityToMatch.id, entity.id);
                }
              });
            }
            
            // リレーションを保存
            const relationsToSave = pendingRelations && pendingRelations.length > 0 ? pendingRelations : topicRelations;
            
            if (relationsToSave && relationsToSave.length > 0) {
              devLog('💾 リレーション保存を開始:', relationsToSave.length, '件');
              
              // エンティティ名からIDのマッピングを取得
              const allEntities = meetingNote?.companyId
                ? await getEntitiesByCompanyId(meetingNote.companyId)
                : await getEntitiesByOrganizationId(organizationId);
              const entitiesInTopic = allEntities.filter(e => {
                if (!e.metadata || typeof e.metadata !== 'object') return false;
                return 'topicId' in e.metadata && e.metadata.topicId === topicId;
              });
              
              const entityNameToIdMap = new Map<string, string>();
              entitiesInTopic.forEach(entity => {
                entityNameToIdMap.set(entity.name.toLowerCase(), entity.id);
              });
              
              for (const relation of relationsToSave) {
                try {
                  if (!relation.sourceEntityId || !relation.targetEntityId) {
                    devWarn('⚠️ リレーションにsourceEntityIdまたはtargetEntityIdがありません:', relation);
                    continue;
                  }
                  
                  const sourceId = pendingIdToCreatedIdMap.get(relation.sourceEntityId) || relation.sourceEntityId;
                  const targetId = pendingIdToCreatedIdMap.get(relation.targetEntityId) || relation.targetEntityId;
                  
                  // sourceIdとtargetIdが既にデータベースに存在するか確認
                  const sourceEntityExists = entitiesInTopic.some(e => e.id === sourceId);
                  const targetEntityExists = entitiesInTopic.some(e => e.id === targetId);
                  
                  if (!sourceEntityExists || !targetEntityExists) {
                    // フォールバック: エンティティ名からIDを取得
                    const sourceEntity = entitiesToSave?.find(e => e.id === relation.sourceEntityId);
                    const targetEntity = entitiesToSave?.find(e => e.id === relation.targetEntityId);
                    
                    if (sourceEntity && targetEntity) {
                      const fallbackSourceId = entityNameToIdMap.get(sourceEntity.name.toLowerCase());
                      const fallbackTargetId = entityNameToIdMap.get(targetEntity.name.toLowerCase());
                      
                      if (fallbackSourceId && fallbackTargetId) {
                        const companyId = relation.companyId || meetingNote?.companyId || undefined;
                        const orgId = companyId 
                          ? (relation.organizationId || organizationId || undefined)
                          : (relation.organizationId || organizationId);
                        
                        if (!orgId && !companyId) {
                          throw new Error('organizationIdまたはcompanyIdが設定されていません');
                        }
                        
                        await createRelation({
                          sourceEntityId: fallbackSourceId,
                          targetEntityId: fallbackTargetId,
                          relationType: relation.relationType,
                          description: relation.description,
                          topicId: topicEmbeddingId,
                          organizationId: orgId,
                          companyId: companyId,
                        });
                        devLog(`✅ リレーション作成成功（フォールバック）: ${relation.relationType}`);
                        continue;
                      }
                    }
                    
                    devWarn('⚠️ リレーション作成スキップ: エンティティIDが見つかりません', {
                      sourcePendingId: relation.sourceEntityId,
                      targetPendingId: relation.targetEntityId,
                    });
                    continue;
                  }
                  
                  // リレーションを作成
                  const companyId = relation.companyId || meetingNote?.companyId || undefined;
                  const orgId = companyId 
                    ? (relation.organizationId || organizationId || undefined)
                    : (relation.organizationId || organizationId);
                  
                  if (!orgId && !companyId) {
                    throw new Error('organizationIdまたはcompanyIdが設定されていません');
                  }
                  
                  await createRelation({
                    topicId: topicEmbeddingId,
                    sourceEntityId: sourceId,
                    targetEntityId: targetId,
                    relationType: relation.relationType,
                    description: relation.description,
                    confidence: relation.confidence,
                    metadata: relation.metadata,
                    organizationId: orgId,
                    companyId: companyId,
                  });
                  
                  devLog(`✅ リレーション作成成功: ${relation.relationType}`);
                } catch (error: any) {
                  console.error('❌ リレーション作成エラー:', {
                    relationType: relation.relationType,
                    error: error?.message || error,
                  });
                  throw new Error(`リレーション「${relation.relationType}」の作成に失敗しました: ${error?.message || error}`);
                }
              }
            }
            
            // 状態を更新
            setMonthContents(updatedContents);
            setHasUnsavedChanges(false);
            setSavingStatus('saved');
            
            // モーダルを閉じる
            setShowTopicModal(false);
            setEditingTopicItemId(null);
            setEditingTopicId(null);
            setTopicTitle('');
            setTopicContent('');
            setTopicSemanticCategory('');
            setTopicKeywords('');
            setTopicSummary('');
            setTopicImportance('');
            setPendingMetadata(null);
            setPendingEntities(null);
            setPendingRelations(null);
            setTopicEntities([]);
            setTopicRelations([]);
            setReplaceExistingEntities(false);
            
            setTimeout(() => setSavingStatus('idle'), 2000);
            devLog('✅ トピック保存完了（エンティティ・リレーション含む）');
          } catch (error: any) {
            console.error('❌ トピック保存エラー:', error);
            alert(`トピックの保存に失敗しました: ${error?.message || '不明なエラー'}`);
            setSavingStatus('idle');
          }
        }}
        setTopicTitle={setTopicTitle}
        setTopicContent={setTopicContent}
        setTopicSemanticCategory={setTopicSemanticCategory}
        setTopicKeywords={setTopicKeywords}
        setTopicSummary={setTopicSummary}
        setTopicImportance={setTopicImportance}
        setPendingMetadata={setPendingMetadata}
        setPendingEntities={setPendingEntities}
        setPendingRelations={setPendingRelations}
        setReplaceExistingEntities={setReplaceExistingEntities}
        setIsGeneratingMetadata={setIsGeneratingMetadata}
        setTopicMetadataModelType={setTopicMetadataModelType}
        setTopicMetadataSelectedModel={setTopicMetadataSelectedModel}
        setTopicMetadataMode={setTopicMetadataMode}
        setEntitySearchQuery={setEntitySearchQuery}
        setEntityTypeFilter={setEntityTypeFilter}
        setShowDeleteEntitiesModal={setShowDeleteEntitiesModal}
        setShowAddEntityModal={setShowAddEntityModal}
        setEditingEntity={setEditingEntity}
        setShowDeleteRelationsModal={setShowDeleteRelationsModal}
        setShowAddRelationModal={setShowAddRelationModal}
        setEditingRelation={setEditingRelation}
        showDeleteEntitiesModal={showDeleteEntitiesModal}
        showDeleteRelationsModal={showDeleteRelationsModal}
        showAddEntityModal={showAddEntityModal}
        showAddRelationModal={showAddRelationModal}
        editingEntity={editingEntity}
        editingRelation={editingRelation}
      />

      {/* AI生成モーダル */}
      <AIGenerationModal
        isOpen={isAIGenerationModalOpen}
        activeTab={activeTab}
        monthContents={monthContents}
        aiModelType={aiModelType}
        aiSelectedModel={aiSelectedModel}
        availableAiModels={availableAiModels}
        loadingAiLocalModels={loadingAiLocalModels}
        aiGenerationInput={aiGenerationInput}
        selectedTopicIdsForAI={selectedTopicIdsForAI}
        selectedSummaryIdsForAI={selectedSummaryIdsForAI}
        aiSummaryFormat={aiSummaryFormat}
        aiSummaryLength={aiSummaryLength}
        aiCustomPrompt={aiCustomPrompt}
        isAIGenerating={isAIGenerating}
        aiGeneratedContent={aiGeneratedContent}
        originalContent={originalContent}
        onSetAiModelType={setAiModelType}
        onSetAiSelectedModel={setAiSelectedModel}
        onSetAIGenerationInput={setAIGenerationInput}
        onSetSelectedTopicIdsForAI={setSelectedTopicIdsForAI}
        onSetSelectedSummaryIdsForAI={setSelectedSummaryIdsForAI}
        onSetAiSummaryFormat={setAiSummaryFormat}
        onSetAiSummaryLength={setAiSummaryLength}
        onSetAiCustomPrompt={setAiCustomPrompt}
        onSetAiGeneratedContent={setAiGeneratedContent}
        onSetOriginalContent={setOriginalContent}
        onGenerate={async () => {
          try {
            if (!aiGenerationInput.trim() && selectedTopicIdsForAI.length === 0 && selectedSummaryIdsForAI.length === 0) {
              alert('概要、月のサマリ、または個別トピックを少なくとも1つ選択してください');
              return;
            }
            
            const currentTabData = monthContents[activeTab] as MonthContent | undefined;
            const isSummaryTab = SUMMARY_TABS.some(t => t.id === activeTab);
            let allTopicsInMonth: Topic[] = [];
            
            if (isSummaryTab) {
              const summaryTabId = activeTab as SummaryTab;
              let targetMonths: MonthTab[] = [];
              
              switch (summaryTabId) {
                case 'q1-summary':
                  targetMonths = ['april', 'may', 'june'];
                  break;
                case 'q2-summary':
                  targetMonths = ['july', 'august', 'september'];
                  break;
                case 'first-half-summary':
                  targetMonths = ['april', 'may', 'june', 'july', 'august', 'september'];
                  break;
                case 'q3-summary':
                  targetMonths = ['october', 'november', 'december'];
                  break;
                case 'q1-q3-summary':
                  targetMonths = ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
                  break;
                case 'q4-summary':
                  targetMonths = ['january', 'february', 'march'];
                  break;
                case 'annual-summary':
                  targetMonths = ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december', 'january', 'february', 'march'];
                  break;
              }
              
              targetMonths.forEach(monthId => {
                const monthData = monthContents[monthId] as MonthContent | undefined;
                if (monthData?.items) {
                  monthData.items.forEach(item => {
                    if (item.topics && item.topics.length > 0) {
                      allTopicsInMonth.push(...item.topics);
                    }
                  });
                }
              });
            } else {
              if (currentTabData?.items) {
                currentTabData.items.forEach(item => {
                  if (item.topics && item.topics.length > 0) {
                    allTopicsInMonth.push(...item.topics);
                  }
                });
              }
            }
            
            const selectedTopics = allTopicsInMonth.filter(topic => selectedTopicIdsForAI.includes(topic.id));
            
            // 選択したサマリを取得
            const selectedSummaries: Array<{ monthId: MonthTab; summary: string; label: string }> = [];
            if (isSummaryTab) {
              const summaryTabId = activeTab as SummaryTab;
              let targetMonths: MonthTab[] = [];
              
              switch (summaryTabId) {
                case 'q1-summary':
                  targetMonths = ['april', 'may', 'june'];
                  break;
                case 'q2-summary':
                  targetMonths = ['july', 'august', 'september'];
                  break;
                case 'first-half-summary':
                  targetMonths = ['april', 'may', 'june', 'july', 'august', 'september'];
                  break;
                case 'q3-summary':
                  targetMonths = ['october', 'november', 'december'];
                  break;
                case 'q1-q3-summary':
                  targetMonths = ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
                  break;
                case 'q4-summary':
                  targetMonths = ['january', 'february', 'march'];
                  break;
                case 'annual-summary':
                  targetMonths = ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december', 'january', 'february', 'march'];
                  break;
              }
              
              targetMonths.forEach(monthId => {
                const monthData = monthContents[monthId] as MonthContent | undefined;
                if (monthData?.summaryId && selectedSummaryIdsForAI.includes(monthData.summaryId)) {
                  const monthLabel = MONTHS.find(m => m.id === monthId)?.label || monthId;
                  selectedSummaries.push({
                    monthId,
                    summary: monthData.summary || '',
                    label: monthLabel,
                  });
                }
              });
            }
            
            setIsAIGenerating(true);
            const summary = await generateAISummary(aiGenerationInput, selectedTopics, selectedSummaries);
            
            // 既存の内容を保存
            const currentContent = currentTabData?.summary || '';
            
            // 状態を設定（比較ビューを表示するため）
            setOriginalContent(currentContent);
            setAiGeneratedContent(summary);
            setIsAIGenerating(false);
          } catch (error: any) {
            setIsAIGenerating(false);
            alert(`エラーが発生しました: ${error.message || '不明なエラー'}`);
          }
        }}
        onApply={() => {
          // 生成結果をサマリに適用
          const currentTabData = monthContents[activeTab] as MonthContent | undefined;
          if (currentTabData && aiGeneratedContent) {
            const updatedContents = { ...monthContents };
            updatedContents[activeTab] = {
              ...currentTabData,
              summary: aiGeneratedContent,
            };
            setMonthContents(updatedContents);
            setHasUnsavedChanges(true);
            // 編集モードに切り替え
            setEditingMonth(activeTab);
            setEditingSection(currentTabData.summaryId ?? null);
            setEditingContent(aiGeneratedContent);
          }
          setAiGeneratedContent(null);
          setOriginalContent(null);
          setIsAIGenerationModalOpen(false);
          setAIGenerationInput('');
          setSelectedTopicIdsForAI([]);
          setSelectedSummaryIdsForAI([]);
          setAiSummaryFormat('auto');
          setAiSummaryLength(500);
          setAiCustomPrompt('');
        }}
        onCancel={() => {
          setAiGeneratedContent(null);
          setOriginalContent(null);
          setAIGenerationInput('');
          setSelectedTopicIdsForAI([]);
          setSelectedSummaryIdsForAI([]);
          setAiSummaryFormat('auto');
          setAiSummaryLength(500);
          setAiCustomPrompt('');
          setIsAIGenerationModalOpen(false);
        }}
      />
      
      {/* 類似トピック検索結果モーダル */}
      <SimilarTopicsModal
        isOpen={showSimilarTopicsModal}
        searchingTopicId={searchingTopicId}
        similarTopics={similarTopics}
        isSearchingSimilarTopics={isSearchingSimilarTopics}
        monthContents={monthContents}
        onClose={() => {
          setShowSimilarTopicsModal(false);
          setSearchingTopicId(null);
          setSimilarTopics([]);
        }}
      />
      
      {/* エンティティ追加・編集モーダル */}
      {showAddEntityModal && showTopicModal && editingTopicId && (
        <AddEntityModal
          isOpen={showAddEntityModal}
          editingEntity={editingEntity}
          onSave={async (name, type) => {
            try {
              if (editingEntity) {
                // 編集モード
                const { updateEntity } = await import('@/lib/entityApi');
                await updateEntity(editingEntity.id, {
                  name,
                  type,
                });
                
                // エンティティリストを更新
                if (pendingEntities) {
                  setPendingEntities(pendingEntities.map(e => 
                    e.id === editingEntity.id ? { ...e, name, type } : e
                  ));
                } else {
                  setTopicEntities(topicEntities.map(e => 
                    e.id === editingEntity.id ? { ...e, name, type } : e
                  ));
                }
                
                alert('エンティティを更新しました');
              } else {
                // 追加モード
                const newEntity = await createEntity({
                  name,
                  type,
                  organizationId: organizationId || undefined,
                  metadata: {
                    topicId: editingTopicId,
                  },
                });
                
                // エンティティリストに追加
                if (pendingEntities) {
                  setPendingEntities([...pendingEntities, newEntity]);
                } else {
                  setTopicEntities([...topicEntities, newEntity]);
                }
                
                alert('エンティティを追加しました');
              }
              
              setShowAddEntityModal(false);
              setEditingEntity(null);
            } catch (error: any) {
              console.error('❌ エンティティ保存エラー:', error);
              alert(`エンティティの保存に失敗しました: ${error.message}`);
            }
          }}
          onCancel={() => {
            setShowAddEntityModal(false);
            setEditingEntity(null);
          }}
        />
      )}
      
      {/* リレーション追加・編集モーダル */}
      {showAddRelationModal && showTopicModal && editingTopicId && (
        <AddRelationModal
          isOpen={showAddRelationModal}
          editingRelation={editingRelation}
          entities={(pendingEntities && pendingEntities.length > 0) ? pendingEntities : topicEntities}
          onSave={async (sourceEntityId, targetEntityId, relationType, description) => {
            try {
              const topicEmbeddingId = `${meetingId}-topic-${editingTopicId}`;
              
              if (editingRelation) {
                // 編集モード
                const { updateRelation } = await import('@/lib/relationApi');
                await updateRelation(editingRelation.id, {
                  sourceEntityId,
                  targetEntityId,
                  relationType,
                  description,
                });
                
                // リレーションリストを更新
                if (pendingRelations) {
                  setPendingRelations(pendingRelations.map(r => 
                    r.id === editingRelation.id ? { ...r, sourceEntityId, targetEntityId, relationType, description } : r
                  ));
                } else {
                  setTopicRelations(topicRelations.map(r => 
                    r.id === editingRelation.id ? { ...r, sourceEntityId, targetEntityId, relationType, description } : r
                  ));
                }
                
                alert('リレーションを更新しました');
              } else {
                // 追加モード
                const newRelation = await createRelation({
                  topicId: topicEmbeddingId,
                  sourceEntityId,
                  targetEntityId,
                  relationType,
                  description,
                  organizationId: organizationId,
                });
                
                // リレーションリストに追加
                if (pendingRelations) {
                  setPendingRelations([...pendingRelations, newRelation]);
                } else {
                  setTopicRelations([...topicRelations, newRelation]);
                }
                
                alert('リレーションを追加しました');
              }
              
              setShowAddRelationModal(false);
              setEditingRelation(null);
            } catch (error: any) {
              console.error('❌ リレーション保存エラー:', error);
              alert(`リレーションの保存に失敗しました: ${error.message}`);
            }
          }}
          onCancel={() => {
            setShowAddRelationModal(false);
            setEditingRelation(null);
          }}
        />
      )}
    </Layout>
  );
}

export default function MeetingNoteDetailPage() {
  return (
    <Suspense fallback={<div>読み込み中...</div>}>
      <MeetingNoteDetailPageContent />
    </Suspense>
  );
}
