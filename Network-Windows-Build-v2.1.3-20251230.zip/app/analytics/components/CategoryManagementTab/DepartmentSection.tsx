'use client';

import { useState, useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import type { Department, Startup, BizDevPhase } from '@/lib/orgApi';
import { useDepartmentManagement } from '../../hooks/useDepartmentManagement';
import { SubTabBar } from './SubTabBar';
import dynamic from 'next/dynamic';
import { formatStartupDate } from '@/lib/orgApi/utils';
import { StartupListModal } from './StartupListModal';

const DynamicVegaChart = dynamic(() => import('@/components/VegaChart'), {
  ssr: false,
  loading: () => (
    <div style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
      グラフを読み込み中...
    </div>
  ),
});

interface DepartmentSectionProps {
  departments: Department[];
  setDepartments: React.Dispatch<React.SetStateAction<Department[]>>;
  startups: Startup[];
  bizDevPhases: BizDevPhase[];
  orderedBizDevPhases: BizDevPhase[];
  departmentManagement: ReturnType<typeof useDepartmentManagement>;
}

export function DepartmentSection({
  departments,
  setDepartments,
  startups,
  bizDevPhases,
  orderedBizDevPhases,
  departmentManagement,
}: DepartmentSectionProps) {
  const router = useRouter();
  const [departmentSubTab, setDepartmentSubTab] = useState<'management' | 'diagram'>('diagram');
  const [viewMode, setViewMode] = useState<'diagram' | 'bar' | 'matrix'>('matrix');
  const [selectedBarDepartmentId, setSelectedBarDepartmentId] = useState<string | null>(null);
  const [selectedMatrixCell, setSelectedMatrixCell] = useState<{ departmentId: string; bizDevPhaseId: string } | null>(null);
  const [selectedBizDevPhaseIds, setSelectedBizDevPhaseIds] = useState<string[]>([]);
  const [isFilterExpanded, setIsFilterExpanded] = useState<boolean>(false);
  const [showTotalStartupModal, setShowTotalStartupModal] = useState<boolean>(false);
  const [showMatchingStartupModal, setShowMatchingStartupModal] = useState<boolean>(false);

  // viewModeが'bar'以外に変更された時にフィルターをリセット
  useEffect(() => {
    if (viewMode !== 'bar') {
      setSelectedBizDevPhaseIds([]);
    }
  }, [viewMode]);

  // フィルター適用後のスタートアップを計算
  const filteredStartups = useMemo(() => {
    if (viewMode === 'bar' && selectedBizDevPhaseIds.length > 0) {
      return startups.filter(startup => {
        const hasBizDevPhase = (startup as any).bizDevPhase && selectedBizDevPhaseIds.includes((startup as any).bizDevPhase);
        return hasBizDevPhase;
      });
    }
    return startups;
  }, [startups, viewMode, selectedBizDevPhaseIds]);

  // 統計情報を計算
  const statistics = useMemo(() => {
    const departmentCount = departments.length;
    
    // 使用するスタートアップデータ（フィルター適用後）
    const startupsToUse = viewMode === 'bar' ? filteredStartups : startups;
    
    // 全スタートアップ数（フィルター適用後の全スタートアップ数）
    const totalStartupCount = startupsToUse.length;
    const totalStartups = startupsToUse;
    
    // 該当スタートアップ数（部署に紐づくスタートアップ、重複除去）
    const uniqueStartupIds = new Set<string>();
    const matchingStartups: Startup[] = [];
    startupsToUse.forEach(startup => {
      if (startup.responsibleDepartments && startup.responsibleDepartments.length > 0) {
        startup.responsibleDepartments.forEach(deptId => {
          if (departments.some(dept => dept.id === deptId)) {
            if (!uniqueStartupIds.has(startup.id)) {
              uniqueStartupIds.add(startup.id);
              matchingStartups.push(startup);
            }
          }
        });
      }
    });
    
    return {
      departmentCount,
      totalStartupCount,
      totalStartups,
      matchingStartupCount: uniqueStartupIds.size,
      matchingStartups,
    };
  }, [departments, startups, viewMode, filteredStartups]);

  // マトリクスデータを生成（部署 × Biz-Devフェーズ）
  // orderedBizDevPhasesとorderedDepartmentsの順序を使用（管理タブの順序に合わせる）
  const matrixData = useMemo(() => {
    const data: Array<{
      department: string;
      departmentId: string;
      bizDevPhase: string;
      bizDevPhaseId: string;
      bizDevPhasePosition: number;
      count: number;
    }> = [];

    // orderedBizDevPhasesが空の場合はbizDevPhasesを使用（フォールバック）
    const phasesToUse = orderedBizDevPhases.length > 0 ? orderedBizDevPhases : bizDevPhases;
    // orderedDepartmentsが空の場合はdepartmentsを使用（フォールバック）
    const departmentsToUse = departmentManagement.orderedDepartments.length > 0 ? departmentManagement.orderedDepartments : departments;

    departmentsToUse.forEach(dept => {
      phasesToUse.forEach((phase, index) => {
        const matchingStartups = startups.filter(startup => 
          startup.responsibleDepartments && startup.responsibleDepartments.includes(dept.id) &&
          (startup as any).bizDevPhase === phase.id
        );
        
        data.push({
          department: dept.title,
          departmentId: dept.id,
          bizDevPhase: phase.title,
          bizDevPhaseId: phase.id,
          // orderedBizDevPhasesのインデックスをpositionとして使用（管理タブの順序を反映）
          bizDevPhasePosition: index,
          count: matchingStartups.length,
        });
      });
    });

    return data;
  }, [departments, bizDevPhases, orderedBizDevPhases, departmentManagement.orderedDepartments, startups]);

  // 部署ごとのスタートアップ件数を集計（フィルター適用後）
  const departmentChartData = useMemo(() => {
    const startupsToUse = viewMode === 'bar' ? filteredStartups : startups;
    return departments.map(dept => {
      const relatedStartups = startupsToUse.filter(startup => 
        startup.responsibleDepartments && startup.responsibleDepartments.includes(dept.id)
      );
      
      return {
        department: dept.title,
        departmentId: dept.id,
        count: relatedStartups.length,
      };
    }).filter(item => item.count > 0); // 0件の部署は除外
  }, [departments, startups, viewMode, filteredStartups]);

  // 棒グラフの仕様を生成
  const barChartSpec = useMemo(() => {
    if (departmentChartData.length === 0) return null;

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const chartHeight = isMobile ? 400 : 500;

    return {
      $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
      description: '部署ごとのスタートアップ件数',
      width: 'container',
      height: chartHeight,
      padding: { top: 20, right: 20, bottom: 60, left: 60 },
      data: {
        values: departmentChartData,
      },
      mark: {
        type: 'bar',
        tooltip: true,
        cursor: 'pointer',
        cornerRadiusTopLeft: 4,
        cornerRadiusTopRight: 4,
        color: '#4262FF',
        stroke: '#FFFFFF',
        strokeWidth: 1,
      },
      encoding: {
        x: {
          field: 'department',
          type: 'ordinal',
          title: '主管事業部署',
          axis: {
            labelAngle: isMobile ? -90 : -45,
            labelLimit: isMobile ? 50 : 120,
            labelFontSize: isMobile ? 11 : 13,
            labelColor: '#4B5563',
            labelFont: 'var(--font-inter), var(--font-noto), sans-serif',
            titleFontSize: isMobile ? 12 : 14,
            titleFontWeight: '600',
            titleColor: '#1A1A1A',
            titleFont: 'var(--font-inter), var(--font-noto), sans-serif',
            titlePadding: 12,
            domain: true,
            domainColor: '#E5E7EB',
            domainWidth: 1,
            tickSize: 0,
          },
          sort: {
            field: 'count',
            order: 'descending',
          },
        },
        y: {
          field: 'count',
          type: 'quantitative',
          title: 'スタートアップ件数',
          axis: {
            grid: true,
            gridColor: '#F3F4F6',
            gridOpacity: 0.5,
            labelFontSize: isMobile ? 11 : 13,
            labelColor: '#6B7280',
            labelFont: 'var(--font-inter), var(--font-noto), sans-serif',
            titleFontSize: isMobile ? 12 : 14,
            titleFontWeight: '600',
            titleColor: '#1A1A1A',
            titleFont: 'var(--font-inter), var(--font-noto), sans-serif',
            titlePadding: 12,
            domain: true,
            domainColor: '#E5E7EB',
            domainWidth: 1,
            tickSize: 0,
          },
        },
        tooltip: [
          { field: 'department', title: '主管事業部署' },
          { field: 'count', title: 'スタートアップ件数', format: ',d' },
        ],
      },
      selection: {
        clicked_theme: {
          type: 'single',
          on: 'click',
          fields: ['departmentId'],
          empty: 'none',
        },
      },
    };
  }, [departmentChartData]);

  // 選択された部署に紐づくスタートアップを取得（フィルター適用後）
  const getSelectedDepartmentStartups = useMemo(() => {
    if (!selectedBarDepartmentId) return [];

    const startupsToUse = viewMode === 'bar' ? filteredStartups : startups;
    return startupsToUse.filter(startup => 
      startup.responsibleDepartments && startup.responsibleDepartments.includes(selectedBarDepartmentId)
    );
  }, [selectedBarDepartmentId, startups, viewMode, filteredStartups]);

  // 選択された部署のスタートアップをBiz-Devフェーズごとにグループ化
  const getSelectedDepartmentStartupsByBizDevPhase = useMemo(() => {
    if (!selectedBarDepartmentId || getSelectedDepartmentStartups.length === 0) return new Map<string, { phase: BizDevPhase | null; startups: Startup[] }>();

    const grouped = new Map<string, { phase: BizDevPhase | null; startups: Startup[] }>();
    
    // Biz-Devフェーズ未設定のグループ
    const noPhaseStartups: Startup[] = [];
    
    getSelectedDepartmentStartups.forEach(startup => {
      if ((startup as any).bizDevPhase) {
        const phase = bizDevPhases.find(p => p.id === (startup as any).bizDevPhase);
        if (phase) {
          const key = phase.id;
          if (!grouped.has(key)) {
            grouped.set(key, { phase, startups: [] });
          }
          grouped.get(key)!.startups.push(startup);
        } else {
          noPhaseStartups.push(startup);
        }
      } else {
        noPhaseStartups.push(startup);
      }
    });
    
    // Biz-Devフェーズ未設定のスタートアップがある場合は追加
    if (noPhaseStartups.length > 0) {
      grouped.set('no-phase', { phase: null, startups: noPhaseStartups });
    }
    
    return grouped;
  }, [selectedBarDepartmentId, getSelectedDepartmentStartups, bizDevPhases]);

  // マトリクスチャートの仕様を生成
  const matrixChartSpec = useMemo(() => {
    if (matrixData.length === 0) return null;

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    const chartHeight = isMobile ? 400 : Math.max(400, bizDevPhases.length * 40 + 100);

    return {
      $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
      description: '主管事業部署 × Biz-Devフェーズ マトリクス',
      width: 'container',
      height: chartHeight,
      padding: { top: 20, right: 20, bottom: 60, left: 120 },
      data: {
        values: matrixData,
      },
      layer: [
        // 1. 背景のrect（ヒートマップ）
        {
          mark: {
            type: 'rect',
            tooltip: true,
            cursor: 'pointer',
            stroke: '#FFFFFF',
            strokeWidth: 2,
          },
          encoding: {
            x: {
              field: 'department',
              type: 'ordinal',
              title: '主管事業部署',
              // orderedDepartmentsの順序をdomainとして明示的に指定
              scale: {
                domain: (departmentManagement.orderedDepartments.length > 0 ? departmentManagement.orderedDepartments : departments).map(d => d.title),
              },
              axis: {
                labelAngle: isMobile ? -90 : -45,
                labelLimit: isMobile ? 50 : 120,
                labelFontSize: isMobile ? 11 : 13,
                labelColor: '#4B5563',
                labelFont: 'var(--font-inter), var(--font-noto), sans-serif',
                titleFontSize: isMobile ? 12 : 14,
                titleFontWeight: '600',
                titleColor: '#1A1A1A',
                titleFont: 'var(--font-inter), var(--font-noto), sans-serif',
                titlePadding: 12,
                domain: true,
                domainColor: '#E5E7EB',
                domainWidth: 1,
                tickSize: 0,
              },
            },
            y: {
              field: 'bizDevPhase',
              type: 'ordinal',
              title: 'Biz-Devフェーズ',
              // orderedBizDevPhasesの順序をdomainとして明示的に指定
              scale: {
                domain: (orderedBizDevPhases.length > 0 ? orderedBizDevPhases : bizDevPhases).map(p => p.title),
              },
              axis: {
                labelFontSize: isMobile ? 11 : 13,
                labelColor: '#4B5563',
                labelFont: 'var(--font-inter), var(--font-noto), sans-serif',
                titleFontSize: isMobile ? 12 : 14,
                titleFontWeight: '600',
                titleColor: '#1A1A1A',
                titleFont: 'var(--font-inter), var(--font-noto), sans-serif',
                titlePadding: 12,
                domain: true,
                domainColor: '#E5E7EB',
                domainWidth: 1,
                tickSize: 0,
              },
            },
            color: {
              field: 'count',
              type: 'quantitative',
              scale: {
                scheme: 'blues',
                domain: [0, Math.max(...matrixData.map(d => d.count), 1)],
              },
              legend: {
                title: '件数',
                labelFontSize: isMobile ? 11 : 13,
                labelColor: '#6B7280',
                titleFontSize: isMobile ? 12 : 14,
                titleFontWeight: '600',
                titleColor: '#1A1A1A',
              },
            },
            tooltip: [
              { field: 'department', title: '主管事業部署' },
              { field: 'bizDevPhase', title: 'Biz-Devフェーズ' },
              { field: 'count', title: 'スタートアップ件数', format: ',d' },
            ],
          },
        },
        // 2. 数字のテキスト
        {
          mark: {
            type: 'text',
            fontSize: isMobile ? 12 : 14,
            fontWeight: '600',
            fill: '#1A1A1A',
            font: 'var(--font-inter), var(--font-noto), sans-serif',
          },
          encoding: {
            x: {
              field: 'department',
              type: 'ordinal',
            },
            y: {
              field: 'bizDevPhase',
              type: 'ordinal',
            },
            text: {
              field: 'count',
              type: 'quantitative',
              format: 'd',
            },
            color: {
              condition: {
                test: 'datum.count > 0',
                value: '#1A1A1A',
              },
              value: '#9CA3AF',
            },
          },
        },
      ],
      selection: {
        clicked_theme: {
          type: 'single',
          on: 'click',
          fields: ['departmentId', 'bizDevPhaseId'],
          empty: 'none',
        },
      },
    };
  }, [matrixData, bizDevPhases.length, orderedBizDevPhases, departmentManagement.orderedDepartments, departments]);

  // 選択されたマトリクスセルに紐づくスタートアップを取得
  const getSelectedMatrixStartups = useMemo(() => {
    if (!selectedMatrixCell) return [];

    return startups.filter(startup => 
      startup.responsibleDepartments && startup.responsibleDepartments.includes(selectedMatrixCell.departmentId) &&
      (startup as any).bizDevPhase === selectedMatrixCell.bizDevPhaseId
    );
  }, [selectedMatrixCell, startups]);

  return (
    <>
      <div style={{ 
        marginBottom: '24px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: '600',
          color: '#1A1A1A',
          fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        }}>
          部署管理
        </h3>
        {departmentSubTab === 'management' && (
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              type="button"
              onClick={() => departmentManagement.setShowEditDepartmentsModal(true)}
              style={{
                padding: '8px 16px',
                fontSize: '14px',
                fontWeight: '500',
                color: '#1A1A1A',
                backgroundColor: '#FFFFFF',
                border: '1.5px solid #E0E0E0',
                borderRadius: '6px',
                cursor: 'pointer',
              }}
            >
              編集
            </button>
            <button
              type="button"
              onClick={() => {
                departmentManagement.setEditingDepartment(null);
                departmentManagement.setDepartmentFormTitle('');
                departmentManagement.setDepartmentFormDescription('');
                departmentManagement.setShowDepartmentModal(true);
              }}
              style={{
                padding: '8px 16px',
                fontSize: '14px',
                fontWeight: '500',
                color: '#FFFFFF',
                backgroundColor: '#4262FF',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
              }}
            >
              部署を追加
            </button>
          </div>
        )}
      </div>

      <SubTabBar
        activeTab={departmentSubTab}
        onTabChange={setDepartmentSubTab}
        managementLabel="部署管理"
        diagramLabel="部署関係性図"
      />

      {/* 部署管理サブタブ */}
      {departmentSubTab === 'management' && (
        <div>
          {departments.length === 0 ? (
            <div style={{ 
              padding: '16px', 
              backgroundColor: '#FFFBF0', 
              border: '1.5px solid #FCD34D', 
              borderRadius: '8px',
              color: '#92400E',
              fontSize: '14px',
            }}>
              部署が見つかりません。部署を追加してください。
            </div>
          ) : (
            <div>
              {departments.map((dept) => (
                <div
                  key={dept.id}
                  style={{
                    padding: '16px',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E0E0E0',
                    borderRadius: '8px',
                    marginBottom: '12px',
                  }}
                >
                  <div style={{
                    fontSize: '16px',
                    fontWeight: '600',
                    color: '#1A1A1A',
                    marginBottom: '8px',
                  }}>
                    {dept.title}
                  </div>
                  {dept.description && (
                    <div style={{
                      fontSize: '14px',
                      color: '#4B5563',
                    }}>
                      {dept.description}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 部署関係性図サブタブ */}
      {departmentSubTab === 'diagram' && (
        <div>
          {/* 統計情報カード */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: typeof window !== 'undefined' && window.innerWidth < 768 
              ? '1fr' 
              : 'repeat(3, 1fr)',
            gap: typeof window !== 'undefined' && window.innerWidth < 768 ? '16px' : '20px',
            marginBottom: '32px',
          }}>
            {/* 部署数カード */}
            <div style={{
              padding: '24px',
              backgroundColor: '#FFFFFF',
              border: '1px solid #E5E7EB',
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
              transition: 'all 0.2s ease',
              position: 'relative',
              overflow: 'hidden',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.04)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
            >
              <div style={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '60px',
                height: '60px',
                background: 'linear-gradient(135deg, #F0F4FF 0%, #E0E8FF 100%)',
                borderRadius: '0 12px 0 60px',
                opacity: 0.5,
              }} />
              <div style={{
                fontSize: '13px',
                color: '#6B7280',
                marginBottom: '12px',
                fontWeight: '500',
                letterSpacing: '0.02em',
                textTransform: 'uppercase',
                position: 'relative',
                zIndex: 1,
              }}>
                部署数
              </div>
              <div style={{
                fontSize: '40px',
                fontWeight: '700',
                color: '#1A1A1A',
                lineHeight: '1',
                marginBottom: '4px',
                position: 'relative',
                zIndex: 1,
                fontFamily: 'var(--font-inter), -apple-system, BlinkMacSystemFont, sans-serif',
              }}>
                {statistics.departmentCount}
              </div>
              <div style={{
                fontSize: '13px',
                color: '#9CA3AF',
                fontWeight: '400',
                position: 'relative',
                zIndex: 1,
              }}>
                件の部署
              </div>
            </div>

            {/* 全スタートアップ数カード */}
            <div 
              onClick={() => setShowTotalStartupModal(true)}
              style={{
                padding: '24px',
                backgroundColor: '#FFFFFF',
                border: '1px solid #E5E7EB',
                borderRadius: '12px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
                transition: 'all 0.2s ease',
                position: 'relative',
                overflow: 'hidden',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.04)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '60px',
                height: '60px',
                background: 'linear-gradient(135deg, #FDF2F8 0%, #FCE7F3 100%)',
                borderRadius: '0 12px 0 60px',
                opacity: 0.5,
              }} />
              <div style={{
                fontSize: '13px',
                color: '#6B7280',
                marginBottom: '12px',
                fontWeight: '500',
                letterSpacing: '0.02em',
                textTransform: 'uppercase',
                position: 'relative',
                zIndex: 1,
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}>
                全スタートアップ数
                {viewMode === 'bar' && selectedBizDevPhaseIds.length > 0 && (
                  <span style={{
                    padding: '2px 8px',
                    fontSize: '11px',
                    fontWeight: '600',
                    color: '#4262FF',
                    backgroundColor: '#E0E8FF',
                    borderRadius: '4px',
                    textTransform: 'none',
                    letterSpacing: '0',
                  }}>
                    フィルター適用中
                  </span>
                )}
              </div>
              <div style={{
                fontSize: '40px',
                fontWeight: '700',
                color: '#1A1A1A',
                lineHeight: '1',
                marginBottom: '4px',
                position: 'relative',
                zIndex: 1,
                fontFamily: 'var(--font-inter), -apple-system, BlinkMacSystemFont, sans-serif',
              }}>
                {statistics.totalStartupCount}
              </div>
              <div style={{
                fontSize: '13px',
                color: '#9CA3AF',
                fontWeight: '400',
                position: 'relative',
                zIndex: 1,
              }}>
                件のスタートアップ
              </div>
            </div>

            {/* 該当スタートアップ数カード */}
            <div 
              onClick={() => setShowMatchingStartupModal(true)}
              style={{
                padding: '24px',
                backgroundColor: '#FFFFFF',
                border: '1px solid #E5E7EB',
                borderRadius: '12px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
                transition: 'all 0.2s ease',
                position: 'relative',
                overflow: 'hidden',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.04)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '60px',
                height: '60px',
                background: 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)',
                borderRadius: '0 12px 0 60px',
                opacity: 0.5,
              }} />
              <div style={{
                fontSize: '13px',
                color: '#6B7280',
                marginBottom: '12px',
                fontWeight: '500',
                letterSpacing: '0.02em',
                textTransform: 'uppercase',
                position: 'relative',
                zIndex: 1,
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}>
                該当スタートアップ数
                {viewMode === 'bar' && selectedBizDevPhaseIds.length > 0 && (
                  <span style={{
                    padding: '2px 8px',
                    fontSize: '11px',
                    fontWeight: '600',
                    color: '#4262FF',
                    backgroundColor: '#E0E8FF',
                    borderRadius: '4px',
                    textTransform: 'none',
                    letterSpacing: '0',
                  }}>
                    フィルター適用中
                  </span>
                )}
              </div>
              <div style={{
                fontSize: '40px',
                fontWeight: '700',
                color: '#1A1A1A',
                lineHeight: '1',
                marginBottom: '4px',
                position: 'relative',
                zIndex: 1,
                fontFamily: 'var(--font-inter), -apple-system, BlinkMacSystemFont, sans-serif',
              }}>
                {statistics.matchingStartupCount}
              </div>
              <div style={{
                fontSize: '13px',
                color: '#9CA3AF',
                fontWeight: '400',
                position: 'relative',
                zIndex: 1,
              }}>
                件のスタートアップ
              </div>
            </div>
          </div>

          {/* 表示モード選択 */}
          <div style={{ marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button
              type="button"
              onClick={() => setViewMode('matrix')}
              style={{
                padding: '8px 16px',
                fontSize: '14px',
                fontWeight: viewMode === 'matrix' ? '600' : '400',
                color: viewMode === 'matrix' ? '#FFFFFF' : '#1A1A1A',
                backgroundColor: viewMode === 'matrix' ? '#4262FF' : '#FFFFFF',
                border: '1.5px solid',
                borderColor: viewMode === 'matrix' ? '#4262FF' : '#E0E0E0',
                borderRadius: '6px',
                cursor: 'pointer',
                transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
                fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                whiteSpace: 'nowrap',
              }}
              onMouseEnter={(e) => {
                if (viewMode !== 'matrix') {
                  e.currentTarget.style.borderColor = '#C4C4C4';
                  e.currentTarget.style.backgroundColor = '#FAFAFA';
                }
              }}
              onMouseLeave={(e) => {
                if (viewMode !== 'matrix') {
                  e.currentTarget.style.borderColor = '#E0E0E0';
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }
              }}
            >
              マトリクス
            </button>
            <button
              type="button"
              onClick={() => setViewMode('bar')}
              style={{
                padding: '8px 16px',
                fontSize: '14px',
                fontWeight: viewMode === 'bar' ? '600' : '400',
                color: viewMode === 'bar' ? '#FFFFFF' : '#1A1A1A',
                backgroundColor: viewMode === 'bar' ? '#4262FF' : '#FFFFFF',
                border: '1.5px solid',
                borderColor: viewMode === 'bar' ? '#4262FF' : '#E0E0E0',
                borderRadius: '6px',
                cursor: 'pointer',
                transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
                fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
              onMouseEnter={(e) => {
                if (viewMode !== 'bar') {
                  e.currentTarget.style.borderColor = '#C4C4C4';
                  e.currentTarget.style.backgroundColor = '#FAFAFA';
                }
              }}
              onMouseLeave={(e) => {
                if (viewMode !== 'bar') {
                  e.currentTarget.style.borderColor = '#E0E0E0';
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }
              }}
            >
              棒グラフ
            </button>
          </div>

          {/* Biz-Devフェーズフィルター（棒グラフ表示時のみ） */}
          {viewMode === 'bar' && (
            <div style={{ 
              marginBottom: '24px',
              padding: '16px',
              backgroundColor: '#F9FAFB',
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
            }}>
              <div 
                onClick={() => setIsFilterExpanded(!isFilterExpanded)}
                style={{
                  marginBottom: isFilterExpanded ? '12px' : '0',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#1A1A1A',
                  fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  userSelect: 'none',
                }}
              >
                <span style={{
                  display: 'inline-block',
                  transform: isFilterExpanded ? 'rotate(90deg)' : 'rotate(0deg)',
                  transition: 'transform 0.2s',
                  fontSize: '12px',
                }}>
                  ▶
                </span>
                Biz-Devフェーズでフィルター
                {selectedBizDevPhaseIds.length > 0 && (
                  <span style={{
                    marginLeft: '8px',
                    padding: '2px 6px',
                    fontSize: '11px',
                    fontWeight: '600',
                    color: '#4262FF',
                    backgroundColor: '#E0E8FF',
                    borderRadius: '4px',
                  }}>
                    {selectedBizDevPhaseIds.length}件選択中
                  </span>
                )}
              </div>
              {isFilterExpanded && (
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '12px',
                }}>
                {bizDevPhases.map(phase => {
                  const isSelected = selectedBizDevPhaseIds.includes(phase.id);
                  return (
                    <label
                      key={phase.id}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '8px 12px',
                        backgroundColor: isSelected ? '#E0E8FF' : '#FFFFFF',
                        border: `1.5px solid ${isSelected ? '#4262FF' : '#E0E0E0'}`,
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 150ms',
                        fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                        fontSize: '14px',
                        color: isSelected ? '#4262FF' : '#1A1A1A',
                        fontWeight: isSelected ? '500' : '400',
                      }}
                      onMouseEnter={(e) => {
                        if (!isSelected) {
                          e.currentTarget.style.backgroundColor = '#F5F5F5';
                          e.currentTarget.style.borderColor = '#C4C4C4';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!isSelected) {
                          e.currentTarget.style.backgroundColor = '#FFFFFF';
                          e.currentTarget.style.borderColor = '#E0E0E0';
                        }
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedBizDevPhaseIds([...selectedBizDevPhaseIds, phase.id]);
                          } else {
                            setSelectedBizDevPhaseIds(selectedBizDevPhaseIds.filter(id => id !== phase.id));
                          }
                        }}
                        style={{
                          width: '16px',
                          height: '16px',
                          cursor: 'pointer',
                          accentColor: '#4262FF',
                        }}
                      />
                      <span>{phase.title}</span>
                    </label>
                  );
                })}
                {selectedBizDevPhaseIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setSelectedBizDevPhaseIds([])}
                    style={{
                      padding: '8px 12px',
                      fontSize: '13px',
                      fontWeight: '500',
                      color: '#6B7280',
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E0E0E0',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 150ms',
                      fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#F5F5F5';
                      e.currentTarget.style.borderColor = '#C4C4C4';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#FFFFFF';
                      e.currentTarget.style.borderColor = '#E0E0E0';
                    }}
                  >
                    フィルターをクリア
                  </button>
                )}
                </div>
              )}
            </div>
          )}

          {/* マトリクス表示、棒グラフ表示 */}
          {viewMode === 'matrix' ? (
            matrixChartSpec && matrixData.length > 0 ? (
              <div style={{ marginBottom: '32px' }}>
                <div style={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E5E7EB',
                  borderRadius: '12px',
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
                  padding: '24px',
                  overflow: 'hidden',
                }}>
                  <div style={{
                    marginBottom: '20px',
                    paddingBottom: '16px',
                    borderBottom: '1px solid #F3F4F6',
                  }}>
                    <h3 style={{
                      fontSize: '18px',
                      fontWeight: '600',
                      color: '#1A1A1A',
                      margin: 0,
                      fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                    }}>
                      主管事業部署 × Biz-Devフェーズ マトリクス
                    </h3>
                  </div>
                  <DynamicVegaChart
                    spec={matrixChartSpec}
                    language="vega-lite"
                    chartData={matrixData}
                    noBorder={true}
                    onSignal={(signalName: string, value: any) => {
                      console.log('DepartmentSection matrix onSignal:', signalName, value);
                      if (signalName === 'clicked_theme' || signalName === 'click') {
                        // value.datumからデータを取得
                        if (value && value.datum) {
                          const datum = value.datum;
                          console.log('DepartmentSection matrix datum:', datum);
                          if (datum.departmentId && datum.bizDevPhaseId) {
                            console.log('Setting selectedMatrixCell from datum:', { departmentId: datum.departmentId, bizDevPhaseId: datum.bizDevPhaseId });
                            setSelectedMatrixCell({ departmentId: datum.departmentId, bizDevPhaseId: datum.bizDevPhaseId });
                          }
                        } 
                        // valueから直接取得
                        else if (value && value.departmentId && value.bizDevPhaseId) {
                          console.log('Setting selectedMatrixCell from value:', { departmentId: value.departmentId, bizDevPhaseId: value.bizDevPhaseId });
                          setSelectedMatrixCell({ departmentId: value.departmentId, bizDevPhaseId: value.bizDevPhaseId });
                        }
                        // departmentとbizDevPhaseから検索
                        else if (value && (value.department || value.bizDevPhase)) {
                          const department = value.department ? departments.find(d => d.title === value.department) : null;
                          const bizDevPhase = value.bizDevPhase ? bizDevPhases.find(p => p.title === value.bizDevPhase) : null;
                          if (department && bizDevPhase) {
                            console.log('Setting selectedMatrixCell from department and bizDevPhase:', { departmentId: department.id, bizDevPhaseId: bizDevPhase.id });
                            setSelectedMatrixCell({ departmentId: department.id, bizDevPhaseId: bizDevPhase.id });
                          }
                        }
                        // chartDataから検索
                        else if (value && (value.department || value.bizDevPhase)) {
                          const matchingData = matrixData.find(d => 
                            (value.department ? d.department === value.department : true) &&
                            (value.bizDevPhase ? d.bizDevPhase === value.bizDevPhase : true)
                          );
                          if (matchingData) {
                            console.log('Setting selectedMatrixCell from matchingData:', { departmentId: matchingData.departmentId, bizDevPhaseId: matchingData.bizDevPhaseId });
                            setSelectedMatrixCell({ departmentId: matchingData.departmentId, bizDevPhaseId: matchingData.bizDevPhaseId });
                          }
                        }
                      }
                    }}
                  />
                </div>
                
                {/* 選択されたマトリクスセルのスタートアップ一覧 */}
                {selectedMatrixCell && getSelectedMatrixStartups.length > 0 && (
                  <div style={{ marginTop: '32px' }}>
                    <div style={{
                      marginBottom: '16px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}>
                      <h4 style={{
                        fontSize: '16px',
                        fontWeight: '600',
                        color: '#1A1A1A',
                        margin: 0,
                        fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                      }}>
                        {departments.find(dept => dept.id === selectedMatrixCell.departmentId)?.title} × {bizDevPhases.find(phase => phase.id === selectedMatrixCell.bizDevPhaseId)?.title} に紐づくスタートアップ
                        <span style={{
                          marginLeft: '8px',
                          fontSize: '14px',
                          fontWeight: '400',
                          color: '#6B7280',
                        }}>
                          ({getSelectedMatrixStartups.length}件)
                        </span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setSelectedMatrixCell(null)}
                        style={{
                          padding: '6px 12px',
                          fontSize: '13px',
                          color: '#6B7280',
                          backgroundColor: '#F3F4F6',
                          border: '1px solid #E5E7EB',
                          borderRadius: '6px',
                          cursor: 'pointer',
                        }}
                      >
                        閉じる
                      </button>
                    </div>
                    <div style={{
                      display: 'grid',
                      gridTemplateColumns: typeof window !== 'undefined' && window.innerWidth < 768 
                        ? '1fr' 
                        : 'repeat(auto-fill, minmax(300px, 1fr))',
                      gap: '16px',
                    }}>
                      {getSelectedMatrixStartups.map(startup => (
                        <div
                          key={startup.id}
                          onClick={() => {
                            if (startup.organizationId && startup.id) {
                              router.push(`/organization/${startup.organizationId}/startup/${startup.id}`);
                            }
                          }}
                          style={{
                            padding: '16px',
                            backgroundColor: '#FFFFFF',
                            border: '1px solid #E5E7EB',
                            borderRadius: '8px',
                            cursor: 'pointer',
                            transition: 'all 0.2s ease',
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.borderColor = '#4262FF';
                            e.currentTarget.style.boxShadow = '0 2px 8px rgba(66, 98, 255, 0.1)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.borderColor = '#E5E7EB';
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        >
                          <div style={{
                            fontSize: '15px',
                            fontWeight: '600',
                            color: '#1A1A1A',
                            marginBottom: '8px',
                            fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                          }}>
                            {startup.title}
                          </div>
                          {startup.createdAt && (() => {
                            const formattedDate = formatStartupDate(startup.createdAt);
                            return formattedDate ? (
                              <div style={{
                                fontSize: '12px',
                                color: '#9CA3AF',
                                marginTop: '8px',
                              }}>
                                作成日: {formattedDate}
                              </div>
                            ) : null;
                          })()}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div style={{
                padding: '40px',
                textAlign: 'center',
                backgroundColor: '#F9FAFB',
                border: '1px solid #E5E7EB',
                borderRadius: '8px',
                color: '#6B7280',
                fontSize: '14px',
                fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}>
                マトリクスデータがありません。
              </div>
            )
          ) : viewMode === 'bar' ? (
            barChartSpec && departmentChartData.length > 0 ? (
              <div style={{ marginBottom: '32px' }}>
                <div style={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E5E7EB',
                  borderRadius: '12px',
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
                  padding: '24px',
                  overflow: 'hidden',
                }}>
                  <div style={{
                    marginBottom: '20px',
                    paddingBottom: '16px',
                    borderBottom: '1px solid #F3F4F6',
                  }}>
                    <h3 style={{
                      fontSize: '18px',
                      fontWeight: '600',
                      color: '#1A1A1A',
                      margin: 0,
                      fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                    }}>
                      部署別スタートアップ件数
                    </h3>
                  </div>
                  <DynamicVegaChart
                    spec={barChartSpec}
                    language="vega-lite"
                    chartData={departmentChartData}
                    noBorder={true}
                    onSignal={(signalName: string, value: any) => {
                      // VegaChartのクリックイベントを処理
                      console.log('DepartmentSection onSignal:', signalName, value);
                      if (signalName === 'clicked_theme' || signalName === 'click') {
                        let departmentId: string | null = null;
                        
                        // value.datumから部署情報を取得
                        if (value && value.datum) {
                          const datum = value.datum;
                          console.log('DepartmentSection datum:', datum);
                          if (datum.departmentId) {
                            // 配列の場合は最初の要素を取得
                            departmentId = Array.isArray(datum.departmentId) ? datum.departmentId[0] : datum.departmentId;
                          } else if (datum.department) {
                            const clickedDept = departments.find(dept => dept.title === datum.department);
                            if (clickedDept) {
                              departmentId = clickedDept.id;
                            }
                          }
                        }
                        // value.departmentIdから取得（配列の場合も対応）
                        else if (value && value.departmentId) {
                          departmentId = Array.isArray(value.departmentId) ? value.departmentId[0] : value.departmentId;
                        }
                        // value.vlPointから取得（Vega-Liteのポイントデータ）
                        else if (value && value.vlPoint) {
                          const point = value.vlPoint;
                          if (point.datum) {
                            const datum = point.datum;
                            if (datum.departmentId) {
                              departmentId = Array.isArray(datum.departmentId) ? datum.departmentId[0] : datum.departmentId;
                            } else if (datum.department) {
                              const clickedDept = departments.find(dept => dept.title === datum.department);
                              if (clickedDept) {
                                departmentId = clickedDept.id;
                              }
                            }
                          }
                        }
                        // value.departmentから取得
                        else if (value && value.department) {
                          const clickedDept = departments.find(dept => dept.title === value.department);
                          if (clickedDept) {
                            departmentId = clickedDept.id;
                          }
                        }
                        
                        if (departmentId) {
                          console.log('Setting selectedBarDepartmentId:', departmentId);
                          setSelectedBarDepartmentId(departmentId);
                        } else {
                          console.warn('DepartmentSection: Could not find departmentId from value:', value);
                        }
                      }
                    }}
                  />
                </div>
                
                {/* 選択された部署のスタートアップ一覧 */}
                {selectedBarDepartmentId && (
                  <div style={{ marginTop: '32px' }}>
                    <div style={{
                      marginBottom: '16px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}>
                      <h4 style={{
                        fontSize: '16px',
                        fontWeight: '600',
                        color: '#1A1A1A',
                        margin: 0,
                        fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                      }}>
                        {departments.find(dept => dept.id === selectedBarDepartmentId)?.title} に紐づくスタートアップ
                        <span style={{
                          marginLeft: '8px',
                          fontSize: '14px',
                          fontWeight: '400',
                          color: '#6B7280',
                        }}>
                          ({getSelectedDepartmentStartups.length}件)
                        </span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setSelectedBarDepartmentId(null)}
                        style={{
                          padding: '6px 12px',
                          fontSize: '13px',
                          fontWeight: '500',
                          color: '#6B7280',
                          backgroundColor: '#FFFFFF',
                          border: '1px solid #E0E0E0',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          transition: 'all 150ms',
                          fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = '#F5F5F5';
                          e.currentTarget.style.borderColor = '#C4C4C4';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = '#FFFFFF';
                          e.currentTarget.style.borderColor = '#E0E0E0';
                        }}
                      >
                        閉じる
                      </button>
                    </div>
                    {getSelectedDepartmentStartups.length === 0 ? (
                      <div style={{
                        padding: '40px',
                        textAlign: 'center',
                        backgroundColor: '#F9FAFB',
                        border: '1px solid #E5E7EB',
                        borderRadius: '8px',
                        color: '#6B7280',
                        fontSize: '14px',
                        fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                      }}>
                        該当するスタートアップはありません。
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
                        {(() => {
                          // orderedBizDevPhasesの順序に従ってソート
                          const entries = Array.from(getSelectedDepartmentStartupsByBizDevPhase.entries());
                          const sortedEntries = entries.sort(([phaseIdA], [phaseIdB]) => {
                            // Biz-Devフェーズ未設定は最後に
                            if (phaseIdA === 'no-phase') return 1;
                            if (phaseIdB === 'no-phase') return -1;
                            
                            // orderedBizDevPhasesの順序に従ってソート
                            const indexA = orderedBizDevPhases.findIndex(p => p.id === phaseIdA);
                            const indexB = orderedBizDevPhases.findIndex(p => p.id === phaseIdB);
                            
                            // どちらもorderedBizDevPhasesにない場合は元の順序を維持
                            if (indexA === -1 && indexB === -1) return 0;
                            if (indexA === -1) return 1;
                            if (indexB === -1) return -1;
                            
                            return indexA - indexB;
                          });
                          
                          return sortedEntries.map(([phaseId, { phase, startups: phaseStartups }]) => (
                            <div key={phaseId}>
                            <div style={{
                              marginBottom: '16px',
                              paddingBottom: '12px',
                              borderBottom: '2px solid #E5E7EB',
                            }}>
                              <h5 style={{
                                fontSize: '16px',
                                fontWeight: '600',
                                color: '#1A1A1A',
                                margin: 0,
                                fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                              }}>
                                {phase ? phase.title : 'Biz-Devフェーズ未設定'}
                                <span style={{
                                  marginLeft: '8px',
                                  fontSize: '14px',
                                  fontWeight: '400',
                                  color: '#6B7280',
                                }}>
                                  ({phaseStartups.length}件)
                                </span>
                              </h5>
                            </div>
                            <div style={{
                              display: 'grid',
                              gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                              gap: '16px',
                            }}>
                              {phaseStartups.map((startup) => (
                                <div
                                  key={startup.id}
                                  onClick={() => {
                                    if (startup.organizationId && startup.id) {
                                      router.push(`/organization/startup?organizationId=${startup.organizationId}&startupId=${startup.id}`);
                                    }
                                  }}
                                  style={{
                                    padding: '16px',
                                    backgroundColor: '#FFFFFF',
                                    border: '1px solid #E5E7EB',
                                    borderRadius: '8px',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s ease',
                                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                                  }}
                                  onMouseEnter={(e) => {
                                    e.currentTarget.style.backgroundColor = '#F9FAFB';
                                    e.currentTarget.style.borderColor = '#3B82F6';
                                    e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
                                    e.currentTarget.style.transform = 'translateY(-2px)';
                                  }}
                                  onMouseLeave={(e) => {
                                    e.currentTarget.style.backgroundColor = '#FFFFFF';
                                    e.currentTarget.style.borderColor = '#E5E7EB';
                                    e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
                                    e.currentTarget.style.transform = 'translateY(0)';
                                  }}
                                >
                                  <h5 style={{
                                    fontSize: '16px',
                                    fontWeight: '600',
                                    color: '#1A1A1A',
                                    margin: '0 0 8px 0',
                                    fontFamily: 'var(--font-inter), var(--font-noto), sans-serif',
                                  }}>
                                    {startup.title}
                                  </h5>
                                  {startup.createdAt && (() => {
                                    const formattedDate = formatStartupDate(startup.createdAt);
                                    return formattedDate ? (
                                      <div style={{
                                        fontSize: '12px',
                                        color: '#9CA3AF',
                                        marginTop: '8px',
                                      }}>
                                        作成日: {formattedDate}
                                      </div>
                                    ) : null;
                                  })()}
                                </div>
                            ))}
                          </div>
                        </div>
                          ));
                        })()}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div style={{
                padding: '40px',
                textAlign: 'center',
                backgroundColor: '#F9FAFB',
                border: '1px solid #E5E7EB',
                borderRadius: '8px',
                color: '#6B7280',
                fontSize: '14px',
                fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}>
                データがありません。
              </div>
            )
          ) : (
            <div style={{
              padding: '40px',
              textAlign: 'center',
              backgroundColor: '#F9FAFB',
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
              color: '#6B7280',
              fontSize: '14px',
              fontFamily: 'var(--font-inter), var(--font-noto), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            }}>
              部署関係性図は準備中です。
            </div>
          )}
        </div>
      )}

      {/* スタートアップ一覧モーダル */}
      <StartupListModal
        isOpen={showTotalStartupModal}
        onClose={() => setShowTotalStartupModal(false)}
        startups={statistics.totalStartups || []}
        title="全スタートアップ一覧"
      />
      <StartupListModal
        isOpen={showMatchingStartupModal}
        onClose={() => setShowMatchingStartupModal(false)}
        startups={statistics.matchingStartups || []}
        title="該当スタートアップ一覧"
      />
    </>
  );
}

